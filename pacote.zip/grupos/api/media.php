<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

function uploadLimit(): int
{
    $bytes = static function (string $value): int {
        $number = (int) $value;
        return $number * (match (strtolower(substr(trim($value), -1))) { 'g' => 1073741824, 'm' => 1048576, 'k' => 1024, default => 1 });
    };
    return min(10 * 1048576, $bytes(ini_get('upload_max_filesize')) ?: PHP_INT_MAX, $bytes(ini_get('post_max_size')) ?: PHP_INT_MAX);
}

function findMedia(string $id): ?array
{
    if (!preg_match('/^[a-f0-9]{32}$/D', $id)) return null;
    $meta = storageRead('media/' . $id, null);
    return is_array($meta) && is_file(DATA_DIR . '/media/' . $id . '.bin') ? $meta : null;
}

function storeMediaUpload(): array
{
    $file = $_FILES['file'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) jsonError('Não foi possível receber o arquivo. Limite do servidor: ' . round(uploadLimit() / 1048576, 1) . ' MB.', 422);
    if ($file['size'] < 1 || $file['size'] > uploadLimit()) jsonError('Arquivo vazio ou acima do limite permitido.', 422);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $types = ['image/jpeg' => 'image', 'image/png' => 'image', 'image/webp' => 'image', 'video/mp4' => 'video', 'application/pdf' => 'document'];
    if (!isset($types[$mime])) jsonError('Formato inválido. Use JPG, PNG, WebP, MP4 ou PDF.', 422);
    if ($types[$mime] === 'image' && !getimagesize($file['tmp_name'])) jsonError('Imagem inválida.', 422);
    $id = bin2hex(random_bytes(16));
    $meta = ['id' => $id, 'name' => basename(str_replace('\\', '/', $file['name'])), 'mime' => $mime, 'type' => $types[$mime], 'size' => $file['size']];
    $dir = DATA_DIR . '/media';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $id . '.bin')) throw new RuntimeException('Falha ao salvar o arquivo.');
    storageWrite('media/' . $id, $meta);
    return $meta;
}

function serveMedia(string $id): never
{
    $media = findMedia($id);
    if (!$media) jsonError('Arquivo não encontrado.', 404);
    header('Content-Type: ' . $media['mime']);
    header('Content-Length: ' . $media['size']);
    header("Content-Disposition: inline; filename*=UTF-8''" . rawurlencode($media['name']));
    header("Content-Security-Policy: default-src 'none'; sandbox");
    readfile(DATA_DIR . '/media/' . $id . '.bin');
    exit;
}

function validateMessageMedia(array &$record): void
{
    if (!in_array($record['type'], ['text', 'media'], true)) jsonError('Tipo de mensagem inválido.');
    if ($record['type'] === 'text') {
        if (trim($record['content']) === '') jsonError('Escreva o conteúdo da mensagem.');
        $record['media_id'] = '';
        $record['media_name'] = '';
        $record['media_url'] = '';
        return;
    }
    if (!empty($record['media_id'])) {
        $media = findMedia($record['media_id']);
        if (!$media) jsonError('Arquivo não encontrado. Envie a mídia novamente.');
        $record['media_type'] = $media['type'];
        $record['media_name'] = $media['name'];
        $record['media_url'] = '';
    } elseif (!filter_var($record['media_url'], FILTER_VALIDATE_URL) || !in_array(parse_url($record['media_url'], PHP_URL_SCHEME), ['https', 'http'], true)) {
        jsonError('Selecione um arquivo ou informe uma URL válida de mídia.');
    }
    if (!in_array($record['media_type'], ['image', 'video', 'document'], true)) jsonError('Tipo de mídia inválido.');
}
