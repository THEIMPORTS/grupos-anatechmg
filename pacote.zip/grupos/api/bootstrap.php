<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const DATA_DIR = __DIR__ . '/../data';
if (is_file(DATA_DIR . '/updating.lock')) {
    http_response_code(503);
    header('Retry-After: 30');
    echo json_encode(['success' => false, 'error' => 'Sistema em atualização. Aguarde e recarregue a página.']);
    exit;
}
set_exception_handler(static function (Throwable $error): void {
    error_log((string) $error);
    jsonError($error instanceof RuntimeException ? $error->getMessage() : 'Erro interno. Verifique os logs do servidor.', 500);
});

function jsonResponse(mixed $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function jsonError(string $message, int $status = 400, array $extra = []): never
{
    jsonResponse(array_merge(['success' => false, 'error' => $message], $extra), $status);
}

function readJsonFile(string $path, mixed $default = []): mixed
{
    if (!is_file($path)) {
        return $default;
    }

    $content = file_get_contents($path);
    if ($content === false || trim($content) === '') {
        return $default;
    }

    $decoded = json_decode($content, true);
    return json_last_error() === JSON_ERROR_NONE ? $decoded : $default;
}

function writeJsonFile(string $path, mixed $data): void
{
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    file_put_contents(
        $path,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    );
}

require_once __DIR__ . '/database.php';

function getConfig(): array
{
    $path = DATA_DIR . '/config.json';

    $defaults = [
        'evogo_base_url' => 'https://evogo.avancex.com.br',
        'global_api_key' => getenv('EVOGO_API_KEY') ?: '',
        'instance_id' => '',
        'instance_token' => '',
        'instance_name' => '',
        'managed_instance_ids' => [],
        'managed_instances' => [],
        'send_delay_seconds' => 4,
        'send_delay_min_seconds' => 4,
        'send_delay_max_seconds' => 4,
        'webhook_secret' => '',
        'cronjob_api_key' => '',
        'openai_api_key' => '',
        'public_webhook_url' => '',
        'timezone' => 'America/Sao_Paulo',
    ];

    if (storageRead('config', null) === null) {
        $defaults['webhook_secret'] = bin2hex(random_bytes(16));
        storageWrite('config', $defaults);
    }

    $config = storageRead('config', $defaults);
    $merged = array_merge($defaults, is_array($config) ? $config : []);

    if ($merged['webhook_secret'] === '') {
        $merged['webhook_secret'] = bin2hex(random_bytes(16));
        storageWrite('config', $merged);
    }

    return $merged;
}

function saveConfig(array $config): array
{
    $current = getConfig();
    $merged = array_merge($current, $config);
    storageWrite('config', $merged);
    return $merged;
}

function getRequestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function generateId(): string
{
    return bin2hex(random_bytes(8));
}

function nowIso(): string
{
    return (new DateTimeImmutable('now', new DateTimeZone('America/Sao_Paulo')))->format(DateTimeInterface::ATOM);
}
