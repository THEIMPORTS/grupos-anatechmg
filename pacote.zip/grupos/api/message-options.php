<?php
declare(strict_types=1);
require_once __DIR__ . '/media.php';

function validateMessageOptions(array &$record): void
{
    $record['mention_all'] = (bool) ($record['mention_all'] ?? false);
    $record['button_enabled'] = (bool) ($record['button_enabled'] ?? false);
    if (!$record['button_enabled']) return;
    $record['button_label'] = trim((string) ($record['button_label'] ?? ''));
    $record['button_url'] = trim((string) ($record['button_url'] ?? ''));
    if (!in_array($record['button_type'], ['reply', 'url'], true)) jsonError('Tipo de botão inválido.');
    if ($record['button_label'] === '' || strlen($record['button_label']) > 80) jsonError('Informe um texto curto para o botão (até 20 caracteres).');
    if (trim($record['content']) === '') jsonError('Escreva o texto que acompanha o botão.');
    if ($record['type'] === 'media' && $record['media_type'] !== 'image') jsonError('Mensagens com botão aceitam imagem ou somente texto.');
    if ($record['button_type'] === 'url') {
        if (!filter_var($record['button_url'], FILTER_VALIDATE_URL) || !in_array(parse_url($record['button_url'], PHP_URL_SCHEME), ['https', 'http'], true)) jsonError('Informe um link HTTP ou HTTPS válido para o botão.');
        if ($record['type'] === 'media' && $record['mention_all']) jsonError('Imagem com botão de link não suporta mencionar todos nesta API. Use botão de resposta ou desative a menção.');
    }
}

function interactiveImageUrl(array $message): string
{
    if (empty($message['media_id'])) return $message['media_url'] ?? '';
    if (!findMedia($message['media_id'])) throw new RuntimeException('Imagem não encontrada.');
    $config = getConfig();
    $base = rtrim($config['public_webhook_url'], '/');
    if (!filter_var($base, FILTER_VALIDATE_URL) || parse_url($base, PHP_URL_SCHEME) !== 'https') throw new RuntimeException('Para imagem enviada por arquivo com botão, configure a URL pública HTTPS do sistema ou use uma URL pública da imagem.');
    $expires = time() + 300;
    $signature = hash_hmac('sha256', $message['media_id'] . ':' . $expires, $config['webhook_secret']);
    return $base . '/api/button-media.php?id=' . rawurlencode($message['media_id']) . '&expires=' . $expires . '&signature=' . $signature;
}

function sendButtonMessage(EvogoClient $client, string $jid, array $message, bool $mentionAll): array
{
    $image = ($message['type'] ?? 'text') === 'media';
    $link = ($message['button_type'] ?? 'reply') === 'url';
    if ($image && $link) {
        if ($mentionAll) throw new RuntimeException('Imagem com botão de link não suporta menção a todos. Desative a menção ou use botão de resposta.');
        return $client->request('POST', '/send/carousel', [
            'number' => $jid, 'cards' => [[
                'header' => ['imageUrl' => interactiveImageUrl($message)],
                'body' => ['text' => $message['content']],
                'buttons' => [['type' => 'URL', 'displayText' => $message['button_label'], 'id' => $message['button_url']]],
            ]],
        ]);
    }
    $button = ['type' => $link ? 'url' : 'reply', 'displayText' => $message['button_label']];
    $button[$link ? 'url' : 'id'] = $link ? $message['button_url'] : 'message-' . $message['id'];
    $payload = ['number' => $jid, 'title' => $message['title'], 'description' => $message['content'], 'footer' => '', 'buttons' => [$button], 'mentionAll' => $mentionAll];
    if ($image) $payload['imageUrl'] = interactiveImageUrl($message);
    return $client->request('POST', '/send/button', $payload);
}
