<?php
declare(strict_types=1);
require_once __DIR__ . '/services.php';

function getQueues(): array { return storageRead('queues', []); }
function saveQueues(array $queues): void { storageWrite('queues', array_values($queues)); }
function findQueue(string $id): ?array
{
    foreach (getQueues() as $queue) if ($queue['id'] === $id) return $queue;
    return null;
}
function putQueue(array $record): void
{
    $queues = getQueues();
    foreach ($queues as $index => $queue) {
        if ($queue['id'] === $record['id']) { $queues[$index] = $record; saveQueues($queues); return; }
    }
    $queues[] = $record;
    saveQueues($queues);
}

// For overnight windows, weekdays refer to the day on which the window starts.
function queueWindow(array $queue, DateTimeImmutable $now): ?array
{
    $now = $now->setTimezone(new DateTimeZone($queue['timezone']));
    foreach ([$now, $now->modify('-1 day')] as $day) {
        if (!in_array((int) $day->format('w'), $queue['days'], true)) continue;
        $start = new DateTimeImmutable($day->format('Y-m-d') . ' ' . $queue['start_time'], $now->getTimezone());
        $end = new DateTimeImmutable($day->format('Y-m-d') . ' ' . $queue['end_time'], $now->getTimezone());
        if ($end <= $start) $end = $end->modify('+1 day');
        if ($now >= $start && $now < $end) return [$start, $end];
    }
    return null;
}

function queueSlot(array $queue, DateTimeImmutable $now): ?DateTimeImmutable
{
    if (($queue['schedule_mode'] ?? 'interval') === 'times') {
        $now = $now->setTimezone(new DateTimeZone($queue['timezone']));
        if (!in_array((int) $now->format('w'), $queue['days'], true)) return null;
        $latest = null;
        foreach ($queue['send_times'] ?? [] as $time) {
            $slot = new DateTimeImmutable($now->format('Y-m-d') . ' ' . $time, $now->getTimezone());
            if ($slot <= $now && $now->getTimestamp() - $slot->getTimestamp() < 300) $latest = $slot;
        }
        return $latest;
    }
    $window = queueWindow($queue, $now);
    if (!$window) return null;
    $seconds = $queue['interval_minutes'] * 60;
    $timestamp = $window[0]->getTimestamp() + intdiv($now->getTimestamp() - $window[0]->getTimestamp(), $seconds) * $seconds;
    // Accept delayed callbacks for the latest slot, never replay missed slots.
    if (!empty($queue['last_sent_at']) && $now->getTimestamp() - (new DateTimeImmutable($queue['last_sent_at']))->getTimestamp() < $seconds) return null;
    return $window[0]->setTimestamp($timestamp);
}

function nextQueueTime(array $queue, ?DateTimeImmutable $now = null): ?string
{
    if (!$queue['enabled'] || !empty($queue['in_flight'])) return null;
    $now ??= new DateTimeImmutable();
    $now = $now->setTimezone(new DateTimeZone($queue['timezone']));
    if (($queue['schedule_mode'] ?? 'interval') === 'times') {
        for ($offset = 0; $offset <= 7; $offset++) {
            $day = $now->modify('+' . $offset . ' days');
            if (!in_array((int) $day->format('w'), $queue['days'], true)) continue;
            foreach ($queue['send_times'] ?? [] as $time) {
                $slot = new DateTimeImmutable($day->format('Y-m-d') . ' ' . $time, $now->getTimezone());
                if ($slot > $now && $slot->getTimestamp() > (int) ($queue['last_slot'] ?? 0)) return $slot->format(DateTimeInterface::ATOM);
            }
        }
        return null;
    }
    for ($offset = -1; $offset <= 8; $offset++) {
        $day = $now->modify(sprintf('%+d days', $offset));
        if (!in_array((int) $day->format('w'), $queue['days'], true)) continue;
        $start = new DateTimeImmutable($day->format('Y-m-d') . ' ' . $queue['start_time'], $now->getTimezone());
        $end = new DateTimeImmutable($day->format('Y-m-d') . ' ' . $queue['end_time'], $now->getTimezone());
        if ($end <= $start) $end = $end->modify('+1 day');
        for ($slot = $start; $slot < $end; $slot = $slot->modify('+' . $queue['interval_minutes'] . ' minutes')) {
            if ($slot > $now && $slot->getTimestamp() > (int) ($queue['last_slot'] ?? 0)) return $slot->format(DateTimeInterface::ATOM);
        }
    }
    return null;
}

function queueCronPayload(array $queue): array
{
    $config = getConfig();
    return [
        'title' => 'Fila Grupos: ' . $queue['title'],
        'url' => rtrim($config['public_webhook_url'], '/') . '/api/dispatch.php?queue=' . rawurlencode($queue['id']),
        'enabled' => $queue['enabled'], 'saveResponses' => true, 'requestMethod' => 1, 'requestTimeout' => 150,
        'extendedData' => ['headers' => ['X-Webhook-Secret' => $config['webhook_secret']]],
        'schedule' => ['timezone' => $queue['timezone'], 'expiresAt' => 0, 'minutes' => [-1], 'hours' => [-1], 'mdays' => [-1], 'months' => [-1], 'wdays' => [-1]],
    ];
}

function syncQueueCron(array $queue): int
{
    requirePublicCronConfig();
    $client = CronJobClient::fromConfig();
    $id = (int) ($queue['cron_job_id'] ?? 0);
    $result = $id ? $client->updateJob($id, queueCronPayload($queue)) : $client->createJob(queueCronPayload($queue));
    if ($id && $result['status'] === 404) { $result = $client->createJob(queueCronPayload($queue)); $id = 0; }
    if (!$result['success']) throw new RuntimeException('Falha ao configurar fila no cron-job.org (HTTP ' . $result['status'] . ').');
    $id = $id ?: (int) ($result['data']['jobId'] ?? 0);
    if (!$id) throw new RuntimeException('cron-job.org não retornou o identificador da fila.');
    return $id;
}

function validateQueue(array $body, ?array $old): array
{
    $title = trim((string) ($body['title'] ?? ''));
    $group = $body['group'] ?? [];
    $ids = array_values(array_unique(array_map('strval', (array) ($body['message_ids'] ?? []))));
    $days = array_values(array_unique(array_map('intval', (array) ($body['days'] ?? []))));
    $start = (string) ($body['start_time'] ?? '');
    $end = (string) ($body['end_time'] ?? '');
    $interval = filter_var($body['interval_minutes'] ?? null, FILTER_VALIDATE_INT);
    $mode = $body['schedule_mode'] ?? 'interval';
    if (!in_array($mode, ['interval', 'times'], true)) jsonError('Modo de horário inválido.');
    $times = array_values(array_unique((array) ($body['send_times'] ?? [])));
    foreach ($times as $time) if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) jsonError('Horário inválido. Use HH:MM.');
    sort($times);
    if ($mode === 'times' && !$times) jsonError('Informe pelo menos um horário.');
    if ($title === '' || strlen($title) > 200) jsonError('Informe um título de até 200 caracteres.');
    if (!is_array($group) || empty($group['instance_id']) || !preg_match('/^[0-9-]+@g\.us$/D', (string) ($group['jid'] ?? ''))) jsonError('Selecione o grupo e sua instância.');
    if (count($ids) < 2) jsonError('Selecione pelo menos dois produtos para evitar repetições seguidas.');
    foreach ($ids as $id) if (!findMessage($id)) jsonError('Um dos produtos selecionados não existe.');
    if (!$days || array_diff($days, range(0, 6))) jsonError('Selecione os dias de envio.');
    if (!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $start) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $end) || $start === $end) jsonError('Informe horários de início e término diferentes.');
    if ($interval === false || $interval < 1 || $interval > 1440) jsonError('O intervalo deve ser de 1 a 1440 minutos.');
    $order = array_values(array_intersect($old['order'] ?? [], $ids));
    $new = array_values(array_diff($ids, $order));
    shuffle($new);
    $order = array_merge($order, $new);
    if (($order[0] ?? '') === ($old['last_message_id'] ?? null)) $order[] = array_shift($order);
    return array_merge($old ?? [], [
        'id' => $old['id'] ?? generateId(), 'title' => $title,
        'group' => ['jid' => (string) $group['jid'], 'instance_id' => (string) $group['instance_id'], 'name' => (string) ($group['name'] ?? $group['jid'])],
        'message_ids' => $ids, 'order' => $order, 'days' => $days, 'start_time' => $start, 'end_time' => $end,
        'interval_minutes' => $interval, 'timezone' => $old['timezone'] ?? getConfig()['timezone'],
        'schedule_mode' => $mode, 'send_times' => $times,
        'enabled' => (bool) ($old['enabled'] ?? false), 'created_at' => $old['created_at'] ?? nowIso(), 'updated_at' => nowIso(),
    ]);
}

function handleQueues(string $action): never
{
    if ($action === 'queues-list') {
        $queues = array_map(static fn ($q) => array_merge($q, ['next_at' => nextQueueTime($q)]), getQueues());
        jsonResponse(['success' => true, 'queues' => $queues]);
    }
    $body = getRequestBody();
    $old = findQueue((string) ($body['id'] ?? ''));
    if ($action === 'queues-save') {
        if (!empty($body['id']) && !$old) jsonError('Fila não encontrada.', 404);
        if (!empty($old['in_flight'])) jsonError('Revise o envio interrompido antes de editar esta fila.', 409);
        $queue = validateQueue($body, $old);
        if ($queue['enabled']) $queue['cron_job_id'] = syncQueueCron($queue);
        putQueue($queue);
        jsonResponse(['success' => true, 'queue' => $queue]);
    }
        if (!$old) jsonError('Fila não encontrada.', 404);
    if ($action === 'queues-repair') {
        $old['cron_job_id'] = syncQueueCron($old);
        putQueue($old);
        appendLog(['type'=>'cron','title'=>$old['title'], 'queue_id'=>$old['id'], 'status'=>'completed', 'detail'=>'Agendamento remoto sincronizado com a URL e segredo atuais.']);
        jsonResponse(['success'=>true]);
    }
    if ($action === 'queues-diagnose') {
        $client = CronJobClient::fromConfig();
        if (!$client || empty($old['cron_job_id'])) jsonError('Fila sem agendamento remoto. Configure o cron-job.org e use Reparar cron.', 422);
        $result = $client->request('GET', '/jobs/' . (int) $old['cron_job_id']);
        if (!$result['success']) jsonError('Não foi possível consultar o cron remoto (HTTP ' . $result['status'] . '). Use Reparar cron se o job foi removido.', 502);
        $job = $result['data']['jobDetails'] ?? [];
        $expected = queueCronPayload($old);
        $report = ['enabled'=>(bool)($job['enabled']??false),'lastStatus'=>$job['lastStatus']??null,'lastExecution'=>$job['lastExecution']??0,'nextExecution'=>$job['nextExecution']??0,
            'configuration_matches'=>($job['url']??'') === $expected['url'] && ($job['extendedData']['headers']['X-Webhook-Secret']??'') === getConfig()['webhook_secret'] && ($job['requestMethod']??-1) === 1];
        appendLog(['type'=>'cron','title'=>$old['title'],'status'=>'info','detail'=>'Diagnóstico remoto: ' . json_encode($report, JSON_UNESCAPED_UNICODE)]);
        jsonResponse(['success'=>true, 'diagnostic'=>$report]);
    }
    if ($action === 'queues-toggle') {
        $old['enabled'] = (bool) ($body['enabled'] ?? false);
        if ($old['enabled']) {
            // Reservas antigas são recuperáveis; um timeout nunca deve bloquear a fila.
            if (!empty($old['in_flight'])) $old['in_flight'] = null;
            if (count($old['order']) < 2) jsonError('A fila precisa de pelo menos dois produtos.');
            foreach ($old['message_ids'] as $id) if (!findMessage($id)) jsonError('Produto não encontrado. Edite a fila.');
            $old['cron_job_id'] = syncQueueCron($old);
            $old['error'] = '';
        } else {
            // Local pause takes effect even if the provider is temporarily unavailable.
            putQueue($old);
            if (!empty($old['cron_job_id'])) {
                try { syncQueueCron($old); }
                catch (Throwable $e) { jsonResponse(['success' => true, 'warning' => 'Fila pausada no sistema. Não foi possível pausar o cron remoto; as chamadas serão ignoradas.']); }
            }
        }
        putQueue($old);
        jsonResponse(['success' => true]);
    }
    if ($action === 'queues-reviewed') {
        if (empty($old['in_flight'])) jsonError('Nenhum envio interrompido para revisar.');
        if (!array_key_exists('delivered', $body)) jsonError('Informe se o produto chegou ao grupo.');
        if ($body['delivered']) {
            $old['last_message_id'] = $old['order'][0];
            $old['order'][] = array_shift($old['order']);
        }
        $old['enabled'] = false;
        $old['in_flight'] = null;
        $old['error'] = '';
        putQueue($old);
        jsonResponse(['success' => true]);
    }
    if ($action === 'queues-delete') {
        $old['enabled'] = false;
        putQueue($old);
        deleteCronJobForSchedule($old);
        saveQueues(array_filter(getQueues(), static fn ($q) => $q['id'] !== $old['id']));
        jsonResponse(['success' => true]);
    }
    jsonError('Ação inválida.', 404);
}

// Called while holding application.lock; injected sender is used only by isolated tests.
function processQueue(string $id, ?DateTimeImmutable $now = null, ?callable $sender = null): array
{
    $queue = findQueue($id);
    if (!$queue) return ['success' => true, 'skipped' => 'deleted'];
    $now ??= new DateTimeImmutable();
    $queue['last_check_at'] = $now->format(DateTimeInterface::ATOM);
    if (!empty($queue['in_flight'])) {
        $started = strtotime((string) ($queue['in_flight']['started_at'] ?? '')) ?: 0;
        if ($started && $now->getTimestamp() - $started < 300) {
            $queue['last_check_reason'] = 'Envio anterior ainda em andamento';
            putQueue($queue);
            return ['success' => true, 'skipped' => 'in_flight'];
        }
        // Timeout de rede deixou uma reserva presa: liberar e seguir a fila.
        $queue['in_flight'] = null;
        $queue['error'] = 'Reserva anterior liberada após timeout.';
    }
    if (!$queue['enabled']) { $queue['last_check_reason'] = 'Fila pausada'; putQueue($queue); return ['success' => true, 'skipped' => 'paused']; }
    $slot = queueSlot($queue, $now);
    if (!$slot || $slot->getTimestamp() <= (int) ($queue['last_slot'] ?? 0)) {
        $queue['last_check_reason'] = queueWindow($queue, $now) ? 'Aguardando intervalo entre produtos' : 'Fora dos dias ou da faixa de horário';
        putQueue($queue);
        return ['success' => true, 'skipped' => $queue['last_check_reason']];
    }
    if (count($queue['order'] ?? []) < 2) {
        $queue['enabled']=false; $queue['error']='Fila sem pelo menos dois produtos. Edite a fila.'; putQueue($queue);
        appendLog(['type'=>'queue','title'=>$queue['title'],'status'=>'failed','detail'=>$queue['error']]);
        return ['success'=>false,'error'=>$queue['error']];
    }
    $messageId = $queue['order'][0];
    $message = findMessage($messageId);
    $queue['last_slot'] = $slot->getTimestamp();
    $queue['in_flight'] = ['message_id' => $messageId, 'started_at' => $now->format(DateTimeInterface::ATOM)];
    putQueue($queue); // Reserve before the network call: retries cannot duplicate the send.
    try {
        if (!$message) throw new RuntimeException('Produto da fila não encontrado.');
        $result = $sender ? $sender($queue, $message) : sendSavedMessage(clientForInstance($queue['group']['instance_id']), $queue['group']['jid'], $message);
        if (empty($result['success'])) throw new RuntimeException('Evolution GO (HTTP ' . ($result['status'] ?? 0) . '): ' . safeLogDetail($result['error'] ?? 'Envio não confirmado. Confira o grupo antes de retomar.'));
        $queue['last_message_id'] = $messageId;
        $queue['order'][] = array_shift($queue['order']);
        $queue['last_sent_at'] = $now->format(DateTimeInterface::ATOM);
        $queue['in_flight'] = null;
        $queue['error'] = '';
    } catch (Throwable $error) {
        $queue['error'] = $error->getMessage();
        $queue['last_error_at'] = $now->format(DateTimeInterface::ATOM);
        $queue['last_failed_message_id'] = $messageId;
        $queue['failure_count'] = (int) ($queue['failure_count'] ?? 0) + 1;
        // Falha de um produto não pode travar a fila. Libere a reserva e
        // mova o produto para o final para que os demais continuem.
        $queue['in_flight'] = null;
        if (!empty($queue['order'])) $queue['order'][] = array_shift($queue['order']);
    }
    putQueue($queue);
    $failed = !empty($queue['error']);
    appendLog(['type'=>'queue-result','title'=>$queue['title'],'queue_id'=>$id,'status'=>$failed?'failed':'completed','detail'=>$queue['error'] ?: 'Produto enviado: ' . ($message['title'] ?? $messageId),'group_jid'=>$queue['group']['jid'],'instance_id'=>$queue['group']['instance_id']]);
    appendLog(['type' => 'queue', 'title' => $queue['title'] . ' — ' . ($message['title'] ?? $messageId), 'queue_id' => $id, 'message_id' => $messageId, 'status' => $failed ? 'failed' : 'completed', 'groups' => 1, 'failures' => $failed ? 1 : 0]);
    return ['success' => !$failed, 'message_id' => $messageId, 'error' => $queue['error']];
}
