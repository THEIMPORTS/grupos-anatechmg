<?php

declare(strict_types=1);

require_once __DIR__ . '/services.php';
require_once __DIR__ . '/queues.php';

$scheduleId = $_GET['id'] ?? '';
$secret = $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '';

$config = getConfig();

if ($secret === '' || !hash_equals($config['webhook_secret'], $secret)) {
    jsonError('Não autorizado', 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Método não permitido', 405);
$appLock = fopen(DATA_DIR . '/application.lock', 'c');
if (!flock($appLock, LOCK_EX | LOCK_NB)) jsonError('Outro processamento está em andamento.', 409);
databaseLock('application', 0);
set_time_limit(300);
storageWrite('cron-heartbeat', ['at'=>nowIso(),'queue_id'=>(string)($_GET['queue']??''),'schedule_id'=>$scheduleId]);
if (!empty($_GET['queue'])) {
    $result = processQueue((string) $_GET['queue']);
    // Delivery failure is recorded in logs; the scheduler callback itself completed.
    jsonResponse(['success' => true, 'result' => $result]);
}

if ($scheduleId !== '' && $scheduleId !== '{id}') {
    $schedule = findSchedule($scheduleId);
    if ($schedule === null) {
        jsonError('Agendamento não encontrado', 404);
    }
    if (($schedule['status'] ?? '') !== 'pending') jsonResponse(['success' => true, 'skipped' => true]);
    if (new DateTimeImmutable($schedule['scheduled_at'], new DateTimeZone($config['timezone'])) > new DateTimeImmutable()) jsonError('Agendamento ainda não está no horário.', 409);

    $result = executeBroadcast($schedule);
    jsonResponse([
        'success' => $result['success'],
        'schedule_id' => $scheduleId,
        'result' => $result,
    ], $result['success'] ? 200 : 500);
}

$processed = processDueSchedules();
jsonResponse([
    'success' => true,
    'mode' => 'batch',
    'processed' => count($processed),
    'results' => $processed,
]);
