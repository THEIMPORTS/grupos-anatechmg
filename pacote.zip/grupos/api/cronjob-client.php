<?php

declare(strict_types=1);

require_once __DIR__ . '/evogo-client.php';

class CronJobClient
{
    private const BASE_URL = 'https://api.cron-job.org';

    public function __construct(private readonly string $apiKey)
    {
    }

    public static function fromConfig(): ?self
    {
        $config = getConfig();
        if (($config['cronjob_api_key'] ?? '') === '') {
            return null;
        }

        return new self($config['cronjob_api_key']);
    }

    public function request(string $method, string $path, ?array $body = null): array
    {
        $ch = curl_init(self::BASE_URL . $path);

        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json',
        ];

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
        ]);

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
        }

        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $decoded = is_string($response) ? json_decode($response, true) : null;

        return [
            'success' => $status >= 200 && $status < 300,
            'status' => $status,
            'data' => is_array($decoded) ? $decoded : ['raw' => $response],
        ];
    }

    public function createJob(array $job): array
    {
        return $this->request('PUT', '/jobs', ['job' => $job]);
    }

    public function updateJob(int $jobId, array $job): array
    {
        return $this->request('PATCH', '/jobs/' . $jobId, ['job' => $job]);
    }

    public function deleteJob(int $jobId): array
    {
        return $this->request('DELETE', '/jobs/' . $jobId);
    }

    public function listJobs(): array
    {
        return $this->request('GET', '/jobs');
    }
}

function buildDispatchUrl(string $scheduleId): string
{
    $config = getConfig();
    $base = rtrim($config['public_webhook_url'] ?: detectPublicBaseUrl(), '/');
    return $base . '/api/dispatch.php?id=' . urlencode($scheduleId);
}

function detectPublicBaseUrl(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '/api/dispatch.php';
    $basePath = dirname(dirname($script));
    $basePath = str_replace('\\', '/', $basePath);

    if ($basePath === '/' || $basePath === '.') {
        return $scheme . '://' . $host;
    }

    return $scheme . '://' . $host . $basePath;
}

function scheduleToCronJobPayload(array $schedule): array
{
    $config = getConfig();
    $dt = (new DateTimeImmutable($schedule['scheduled_at'], new DateTimeZone($config['timezone'])))->setTimezone(new DateTimeZone($config['timezone']));

    return [
        'title' => 'Grupos: ' . ($schedule['title'] ?? $schedule['id']),
        'url' => buildDispatchUrl($schedule['id']),
        'enabled' => true,
        'saveResponses' => true,
        'requestMethod' => 1,
        'requestTimeout' => 300,
        'extendedData' => ['headers' => ['X-Webhook-Secret' => $config['webhook_secret']]],
        'schedule' => [
            'timezone' => $config['timezone'],
            'expiresAt' => (int) $dt->modify('+1 day')->format('YmdHis'),
            'hours' => [(int) $dt->format('G')],
            'minutes' => [(int) $dt->format('i')],
            'mdays' => [(int) $dt->format('j')],
            'months' => [(int) $dt->format('n')],
            'wdays' => [-1],
        ],
    ];
}

function registerCronJobForSchedule(array $schedule): ?int
{
    $client = CronJobClient::fromConfig();
    if ($client === null) {
        throw new RuntimeException('Configure a API key do cron-job.org antes de agendar.');
    }
    requirePublicCronConfig();
    $jobId = (int) ($schedule['cron_job_id'] ?? 0);
    $result = $jobId ? $client->updateJob($jobId, scheduleToCronJobPayload($schedule)) : $client->createJob(scheduleToCronJobPayload($schedule));
    if (!$result['success']) {
        throw new RuntimeException('Falha ao registrar no cron-job.org (HTTP ' . $result['status'] . '). Verifique a chave e os limites da conta.');
    }
    $id = $jobId ?: (int) ($result['data']['jobId'] ?? 0);
    if (!$id) throw new RuntimeException('cron-job.org não retornou o identificador do agendamento.');
    return $id;
}

function deleteCronJobForSchedule(array $schedule): void
{
    $jobId = (int) ($schedule['cron_job_id'] ?? 0);
    if ($jobId <= 0) {
        return;
    }

    $client = CronJobClient::fromConfig();
    if ($client === null) throw new RuntimeException('Configure a chave cron-job.org para excluir o agendamento remoto.');
    $result = $client->deleteJob($jobId);
    if (!$result['success'] && $result['status'] !== 404) throw new RuntimeException('Não foi possível excluir o agendamento no cron-job.org.');
}

function requirePublicCronConfig(): void
{
    if (!CronJobClient::fromConfig()) throw new RuntimeException("Configure a chave do cron-job.org.");
    $url = getConfig()['public_webhook_url'];
    $host = parse_url($url, PHP_URL_HOST) ?: '';
    if (!filter_var($url, FILTER_VALIDATE_URL) || parse_url($url, PHP_URL_SCHEME) !== 'https' || !str_contains($host, '.') || str_ends_with($host, '.test') || str_ends_with($host, '.local') || (filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE))) {
        throw new RuntimeException('Configure uma URL pública HTTPS deste sistema para o cron-job.org.');
    }
}
