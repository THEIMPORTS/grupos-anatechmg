<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/media.php';

function updateVersion(): string
{
    return (string) (readJsonFile(__DIR__ . '/../version.json', ['version' => '1.0.0'])['version'] ?? '1.0.0');
}

function updatePathAllowed(string $path): bool
{
    if (str_contains($path, '..') || str_contains($path, '\\') || str_contains($path, ':') || preg_match('/[^a-zA-Z0-9_.\/-]/', $path)) return false;
    return in_array($path, ['index.html', 'install.php', 'version.json', '.htaccess'], true)
        || (bool) preg_match('~^api/[a-zA-Z0-9_-]+\.php$~D', $path)
        || (bool) preg_match('~^assets/(?:[a-zA-Z0-9_-]+/)*[a-zA-Z0-9_-]+\.(?:js|css|png|jpg|jpeg|webp|svg|ico|woff2?)$~D', $path);
}

function importCatalogSeedIfPresent(): int
{
    $path = __DIR__ . '/catalog-seed.php';
    if (!is_file($path)) return 0;
    $seed = require $path;
    if (!is_array($seed) || !$seed) return 0;
    $pdo = database();
    $check = $pdo->prepare('SELECT COUNT(*) FROM messages WHERE record_key = ?');
    $insert = $pdo->prepare('INSERT INTO messages (record_key,payload,sort_order) VALUES (?,?,?)');
    $position = (int) $pdo->query('SELECT COALESCE(MAX(sort_order), -1) + 1 FROM messages')->fetchColumn();
    $added = 0;
    foreach ($seed as $row) {
        if (!is_array($row) || empty($row['id']) || empty($row['title'])) continue;
        $check->execute([(string) $row['id']]);
        if ((int) $check->fetchColumn() > 0) continue;
        $insert->execute([(string) $row['id'], json_encode($row, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), $position++]);
        $added++;
    }
    return $added;
}

function inspectUpdate(string $archive, string $current): array
{
    if (!class_exists('ZipArchive')) throw new RuntimeException('Ative a extensão ZIP do PHP para atualizar.');
    $zip = new ZipArchive();
    if ($zip->open($archive) !== true) throw new RuntimeException('O arquivo não é um ZIP válido.');
    try {
        if ($zip->numFiles > 1000) throw new RuntimeException('Pacote com arquivos demais.');
        $manifestStat = $zip->statName('update.json');
        if (!$manifestStat || $manifestStat['size'] > 200000) throw new RuntimeException('Pacote sem manifesto update.json válido.');
        $manifest = json_decode($zip->getFromName('update.json'), true);
        if (!is_array($manifest) || ($manifest['app'] ?? '') !== 'grupos-evogo' || !preg_match('/^\d+\.\d+\.\d+$/D', $manifest['version'] ?? '') || !is_array($manifest['files'] ?? null) || !$manifest['files']) throw new RuntimeException('Manifesto de atualização inválido.');
        if (!version_compare($manifest['version'], $current, '>')) throw new RuntimeException('O pacote precisa ser mais recente que a versão instalada (' . $current . ').');
        $seen = []; $total = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $path = $stat['name'];
            $lower = strtolower($path);
            if (isset($seen[$lower])) throw new RuntimeException('Pacote contém arquivos duplicados.');
            $seen[$lower] = true;
            $zip->getExternalAttributesIndex($i, $os, $attrs);
            if ((($attrs >> 16) & 0170000) === 0120000) throw new RuntimeException('Links simbólicos não são permitidos.');
            if ($path === 'update.json') continue;
            if (!updatePathAllowed($path) || !isset($manifest['files'][$path])) throw new RuntimeException('Arquivo não permitido no pacote: ' . $path);
            $total += $stat['size'];
            if ($stat['size'] > 10 * 1048576 || $total > 50 * 1048576) throw new RuntimeException('Pacote excede o tamanho permitido.');
            $contents = $zip->getFromIndex($i);
            if (!is_string($contents) || !is_string($manifest['files'][$path]) || !hash_equals($manifest['files'][$path], hash('sha256', $contents))) throw new RuntimeException('Arquivo corrompido: ' . $path);
        }
        foreach ($manifest['files'] as $path => $hash) if (!isset($seen[strtolower($path)]) || !updatePathAllowed($path)) throw new RuntimeException('Arquivo ausente ou inválido no manifesto.');
        $version = json_decode($zip->getFromName('version.json') ?: '', true);
        if (($version['version'] ?? '') !== $manifest['version'] || !isset($manifest['files']['version.json'])) throw new RuntimeException('A versão do pacote não corresponde ao manifesto.');
        return $manifest;
    } finally { $zip->close(); }
}

function installUpdate(string $archive): array
{
    $root = realpath(__DIR__ . '/..');
    $before = updateVersion();
    $manifest = inspectUpdate($archive, $before);
    $id = gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4));
    $backup = DATA_DIR . '/updates/' . $id;
    if (!mkdir($backup, 0775, true)) throw new RuntimeException('Não foi possível criar o backup.');
    $zip = new ZipArchive();
    $zip->open($archive);
    $originals = []; $changed = [];
    $maintenance = DATA_DIR . '/updating.lock';
    try {
        foreach ($manifest['files'] as $path => $hash) {
            $target = $root . '/' . $path;
            $parent = dirname($target);
            while ($parent !== $root) {
                if (is_link($parent)) throw new RuntimeException('Diretório de destino contém link simbólico.');
                $parent = dirname($parent);
            }
            if (is_link($target) || is_dir($target)) throw new RuntimeException('Destino inválido: ' . $path);
            if (file_exists($target) && !is_writable($target)) throw new RuntimeException('Sem permissão de escrita: ' . $path);
            $slot = hash('sha256', $path);
            $originals[$path] = is_file($target);
            if ($originals[$path] && !copy($target, $backup . '/' . $slot . '.bak')) throw new RuntimeException('Falha ao copiar backup: ' . $path);
            if (file_put_contents($backup . '/' . $slot . '.new', $zip->getFromName($path)) === false) throw new RuntimeException('Falha ao preparar atualização.');
        }
        writeJsonFile($backup . '/manifest.json', ['from' => $before, 'to' => $manifest['version'], 'originals' => $originals]);
        if (file_put_contents($maintenance, $id) === false) throw new RuntimeException('Não foi possível iniciar manutenção.');
        foreach ($manifest['files'] as $path => $hash) {
            $target = $root . '/' . $path;
            if (!is_dir(dirname($target)) && !mkdir(dirname($target), 0775, true)) throw new RuntimeException('Falha ao criar diretório.');
            $changed[] = $path;
            if (!copy($backup . '/' . hash('sha256', $path) . '.new', $target) || hash_file('sha256', $target) !== $hash) throw new RuntimeException('Falha ao instalar: ' . $path);
            if (function_exists('opcache_invalidate')) opcache_invalidate($target, true);
        }
        $seedAdded = importCatalogSeedIfPresent();
        $history = storageRead('updates/history', []);
        array_unshift($history, ['id' => $id, 'from' => $before, 'version' => $manifest['version'], 'at' => nowIso(), 'files' => count($changed)]);
        storageWrite('updates/history', array_slice($history, 0, 30));
        return ['version' => $manifest['version'], 'backup' => $id, 'files' => count($changed), 'seed_added' => $seedAdded];
    } catch (Throwable $e) {
        $restored = true;
        foreach (array_reverse($changed) as $path) {
            $target = $root . '/' . $path;
            $ok = $originals[$path] ? copy($backup . '/' . hash('sha256', $path) . '.bak', $target) : (!file_exists($target) || unlink($target));
            $restored = $restored && $ok;
            if (function_exists('opcache_invalidate')) opcache_invalidate($target, true);
        }
        if (!$restored) { $maintenance = ''; throw new RuntimeException('Falha na restauração. Sistema em manutenção; backup: ' . $id); }
        throw new RuntimeException('Atualização cancelada; arquivos anteriores preservados. ' . $e->getMessage());
    } finally {
        $zip->close();
        if ($maintenance !== '' && is_file($maintenance)) unlink($maintenance);
    }
}
