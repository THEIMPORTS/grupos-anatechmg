<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

session_name('grupos_session');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'path' => '/']);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));

function requireLogin(): void
{
    if (empty($_SESSION['user'])) jsonError('Faça login para continuar.', 401);
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && !hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) jsonError('Sessão inválida. Atualize a página.', 403);
}

function handleAuth(string $action): void
{
    $file = DATA_DIR . '/admin.json';
    if ($action === 'auth-status') jsonResponse(['success' => true, 'authenticated' => !empty($_SESSION['user']), 'setup' => storageRead('admin', null) === null, 'csrf' => $_SESSION['csrf']]);
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Método não permitido', 405);
    if (!hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) jsonError('Atualize a página e tente novamente.', 403);
    if ($action === 'logout') {
        $_SESSION = [];
        session_destroy();
        jsonResponse(['success' => true]);
    }
    $body = getRequestBody();
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $password = (string) ($body['password'] ?? '');
    $lock = fopen(DATA_DIR . '/auth.lock', 'c');
    flock($lock, LOCK_EX);
    databaseLock('auth');
    if ($action === 'setup') {
        if (storageRead('admin', null) !== null) jsonError('Administrador já cadastrado.', 409);
        $remote = $_SERVER['REMOTE_ADDR'] ?? '';
        if (!in_array($remote, ['127.0.0.1', '::1'], true)) jsonError('Crie o administrador pelo acesso local do servidor.', 403);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) jsonError('Informe um e-mail válido e senha com pelo menos 12 caracteres.');
        storageWrite('admin', ['email' => $email, 'hash' => password_hash($password, PASSWORD_DEFAULT)]);
    } else {
        $attemptFile = DATA_DIR . '/login-attempts.json';
        $attempts = storageRead('login-attempts', []);
        $ip = hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '');
        $entry = $attempts[$ip] ?? ['count' => 0, 'until' => 0];
        if ($entry['until'] < time()) $entry = ['count' => 0, 'until' => time() + 900];
        if ($entry['count'] >= 10) jsonError('Muitas tentativas. Aguarde 15 minutos.', 429);
        $admin = storageRead('admin', []);
        if ($email !== ($admin['email'] ?? null) || !password_verify($password, $admin['hash'] ?? '')) {
            $entry['count']++;
            $attempts[$ip] = $entry;
            storageWrite('login-attempts', $attempts);
            jsonError('E-mail ou senha incorretos.', 401);
        }
        unset($attempts[$ip]);
        storageWrite('login-attempts', $attempts);
    }
    flock($lock, LOCK_UN);
    databaseUnlock('auth');
    fclose($lock);
    session_regenerate_id(true);
    $_SESSION['user'] = $email;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    jsonResponse(['success' => true, 'csrf' => $_SESSION['csrf']]);
}
