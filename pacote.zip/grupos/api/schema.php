<?php
declare(strict_types=1);
function createSchema(PDO $pdo): void
{
    foreach (['app_settings','messages','schedules','queues','group_metadata','activity_logs'] as $table) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `$table` (record_key VARCHAR(191) COLLATE utf8mb4_bin NOT NULL PRIMARY KEY, payload JSON NOT NULL, sort_order INT NOT NULL DEFAULT 0, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}
