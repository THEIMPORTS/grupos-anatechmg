<?php

declare(strict_types=1);

require_once __DIR__ . '/services.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/queues.php';
require_once __DIR__ . '/openai-client.php';
require_once __DIR__ . '/updates.php';

$action = $_GET['action'] ?? 'status';
if (!is_file(getenv('GRUPOS_DB_CONFIG') ?: DATA_DIR . '/database.php')) jsonResponse(['success' => false, 'install_required' => true, 'error' => 'Instale o sistema antes de continuar.'], 503);
if (in_array($action, ['auth-status', 'login', 'setup', 'logout'], true)) handleAuth($action);
requireLogin();
if ($action === 'updates-info') jsonResponse(['success' => true, 'version' => updateVersion(), 'limit' => uploadLimit(), 'zip_available' => class_exists('ZipArchive'), 'history' => storageRead('updates/history', [])]);
$readActions = ['status', 'config-get', 'instances', 'groups', 'messages-list', 'schedules-list', 'logs', 'webhook-url', 'media-file', 'queues-list'];
if (!in_array($action, $readActions, true) && $_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Método não permitido', 405);
$appLock = fopen(DATA_DIR . '/application.lock', 'c');
flock($appLock, LOCK_EX);
databaseLock('application');
session_write_close();
if ($action === 'media-file') serveMedia((string) ($_GET['id'] ?? ''));
if ($action === 'media-upload') jsonResponse(['success' => true, 'media' => storeMediaUpload()]);
if (str_starts_with($action, 'queues-')) handleQueues($action);

switch ($action) {
    case 'updates-install':
        $file = $_FILES['file'] ?? null;
        if (!$file || $file['error'] !== UPLOAD_ERR_OK || $file['size'] > uploadLimit() || !is_uploaded_file($file['tmp_name'])) jsonError('Envie um pacote ZIP dentro do limite do servidor.', 422);
        set_time_limit(180);
        ignore_user_abort(true);
        jsonResponse(['success' => true, 'update' => installUpdate($file['tmp_name'])]);
    case 'generate-copy':
        $body = getRequestBody();
        if (!is_string($body['summary'] ?? null)) jsonError('Escreva um resumo do produto.');
        $summary = trim($body['summary']);
        if ($summary === '' || strlen($summary) > 12000) jsonError('Informe um resumo de até 3.000 caracteres.');
        $key = trim((string) getConfig()['openai_api_key']);
        if ($key === '') jsonError('Insira e salve a chave OpenAI em Configurações para gerar a copy.', 422);
        $last = storageRead('ai-rate', ['at' => 0]);
        if (time() - (int) $last['at'] < 10) jsonError('Aguarde alguns segundos antes de gerar outra copy.', 429);
        storageWrite('ai-rate', ['at' => time()]);
        flock($appLock, LOCK_UN);
        databaseUnlock('application');
        set_time_limit(75);
        jsonResponse(['success' => true, 'copy' => generateCopy($summary, $key)]);
    case 'status':
        $config = getConfig();
        jsonResponse([
            'success' => true,
            'app' => 'Grupos Evogo',
            'version' => '1.0.0',
            'instance' => [
                'id' => $config['instance_id'],
                'name' => $config['instance_name'],
                'has_token' => $config['instance_token'] !== '',
            ],
            'timezone' => $config['timezone'],
        ]);
        break;

    case 'config-get':
        jsonResponse(['success' => true, 'config' => sanitizeConfig(getConfig())]);
        break;

    case 'config-save':
        $body = getRequestBody();
        $allowed = [
            'evogo_base_url',
            'global_api_key',
            'instance_id',
            'instance_token',
            'instance_name',
            'send_delay_seconds',
            'webhook_secret',
            'cronjob_api_key',
            'openai_api_key',
            'public_webhook_url',
            'timezone',
        ];

        $patch = [];
        foreach ($allowed as $key) {
            if (array_key_exists($key, $body) && $body[$key] !== '' && !str_contains((string) $body[$key], '***')) {
                $patch[$key] = $body[$key];
            }
        }

        if (isset($patch['send_delay_seconds'])) {
            $patch['send_delay_seconds'] = min(60, max(1, (int) $patch['send_delay_seconds']));
        }
        if (isset($patch['openai_api_key'])) {
            $patch['openai_api_key'] = trim((string) $patch['openai_api_key']);
            if (strlen($patch['openai_api_key']) > 512 || preg_match('/[\r\n\s]/', $patch['openai_api_key'])) jsonError('A chave OpenAI não pode conter espaços ou quebras de linha.');
        }
        if (!empty($body['remove_openai_key'])) $patch['openai_api_key'] = '';
        if (isset($patch['timezone']) && !in_array($patch['timezone'], DateTimeZone::listIdentifiers(), true)) jsonError('Fuso horário inválido.');
        if (isset($patch['send_delay_min_seconds']) || isset($patch['send_delay_max_seconds'])) {
            $min = max(1, min(3600, (int) ($patch['send_delay_min_seconds'] ?? getConfig()['send_delay_min_seconds'])));
            $max = max($min, min(3600, (int) ($patch['send_delay_max_seconds'] ?? getConfig()['send_delay_max_seconds'])));
            $patch['send_delay_min_seconds'] = $min; $patch['send_delay_max_seconds'] = $max; $patch['send_delay_seconds'] = $min;
        }
        if (isset($patch['evogo_base_url']) && (!filter_var($patch['evogo_base_url'], FILTER_VALIDATE_URL) || parse_url($patch['evogo_base_url'], PHP_URL_SCHEME) !== 'https')) jsonError('A URL Evolution GO deve usar HTTPS.');

        $saved = saveConfig($patch);
        jsonResponse(['success' => true, 'config' => sanitizeConfig($saved)]);
        break;

    case 'instances':
        $result = syncInstanceFromEvogo();
        if (!$result['success']) {
            jsonError($result['error'] ?? 'Falha ao sincronizar instâncias', 500, $result);
        }

        $cfg = getConfig(); $managed = array_values(array_map('strval', (array) ($cfg['managed_instance_ids'] ?? [])));
        $managedNames = array_values(array_map('strval', array_column((array) ($cfg['managed_instances'] ?? []), 'name')));
        $visibleInstances = array_values(array_filter($result['instances'], static fn($i) => in_array((string)($i['id'] ?? ''), $managed, true) || in_array((string)($i['name'] ?? ''), $managedNames, true)));
        jsonResponse([
            'success' => true,
            'instances' => array_map(static fn ($i) => [
                'id' => $i['id'] ?? '',
                'name' => $i['name'] ?? '',
                'connected' => (bool) ($i['connected'] ?? false),
                'jid' => $i['jid'] ?? '',
            ], $visibleInstances),
            'selected' => [
                'id' => $result['selected']['id'] ?? '',
                'name' => $result['selected']['name'] ?? '',
                'connected' => (bool) ($result['selected']['connected'] ?? false),
            ],
            'config' => $result['config'],
        ]);
        break;

    case 'instance-create':
        $body = getRequestBody();
        $name = trim((string) ($body['name'] ?? ''));
        if ($name === '' || !preg_match('/^[a-zA-Z0-9_-]{2,80}$/D', $name)) jsonError('Informe um nome de instância válido.');
        $token = bin2hex(random_bytes(16));
        $result = EvogoClient::globalFromConfig()->request('POST', '/instance/create', [
            'name' => $name, 'instanceName' => $name, 'token' => $token, 'qrcode' => true,
            'integration' => 'WHATSAPP-BAILEYS',
        ]);
        if (!$result['success']) jsonError('Não foi possível criar a instância (HTTP ' . $result['status'] . '): ' . safeLogDetail((string) ($result['error'] ?? 'A API rejeitou os dados enviados.')), 502);
        $created = $result['data']['instance'] ?? $result['data'];
        if (!is_array($created)) $created = [];
        if (empty($created['qrcode']) && empty($created['qrCode']) && empty($created['qr']) && empty($created['base64'])) {
            $qrResult = EvogoClient::forInstance(getConfig()['evogo_base_url'], $token)->request('GET', '/instance/qr');
            if ($qrResult['success'] && is_array($qrResult['data'])) $created = array_merge($created, $qrResult['data']);
        }
        $createdId = (string) ($created['instanceId'] ?? $created['id'] ?? '');
        $managed = array_values(array_map('strval', (array) (getConfig()['managed_instance_ids'] ?? [])));
        if ($createdId !== '' && !in_array($createdId, $managed, true)) { $managed[] = $createdId; saveConfig(['managed_instance_ids' => $managed]); }
        $managedInstances = (array) (getConfig()['managed_instances'] ?? []);
        $managedInstances[] = ['id' => $createdId, 'name' => $name];
        saveConfig(['managed_instances' => $managedInstances]);
        jsonResponse(['success' => true, 'instance' => $created]);
        break;

    case 'instance-qr':
    case 'instance-reconnect':
        $body = getRequestBody(); $name = trim((string) ($body['name'] ?? ''));
        if ($name === '') jsonError('Instância inválida.');
        $config = getConfig();
        $all = EvogoClient::globalFromConfig()->getInstances();
        if (!$all['success']) jsonError('Não foi possível consultar as conexões na Evolution GO.', 502);
        $instance = null;
        foreach ($all['data']['data'] ?? [] as $candidate) {
            if (($candidate['name'] ?? '') === $name) { $instance = $candidate; break; }
        }
        $managedNames = array_column($config['managed_instances'] ?? [], 'name');
        if (!$instance || (!in_array($name, $managedNames, true) && !in_array($instance['id'] ?? '', $config['managed_instance_ids'] ?? [], true))) jsonError('Conexão não cadastrada neste painel.', 404);
        if (empty($instance['token'])) jsonError('A API não retornou o token desta conexão.', 502);
        $client = EvogoClient::forInstance($config['evogo_base_url'], $instance['token']);
        $result = $action === 'instance-qr' ? ['success' => true, 'data' => []] : $client->request('POST', '/instance/connect', ['immediate' => true]);
        if (!$result['success']) jsonError('Não foi possível iniciar a reconexão (HTTP ' . $result['status'] . ').', 502);
        $qr = $client->request('GET', '/instance/qr');
        jsonResponse(['success' => true, 'connection' => $qr['success'] ? ($qr['data']['data'] ?? $qr['data']) : ($result['data']['data'] ?? $result['data'])]);
        break;

    case 'select-instance':
        $body = getRequestBody();
        $instanceId = $body['instance_id'] ?? '';
        if ($instanceId === '') {
            jsonError('instance_id é obrigatório');
        }

        $sync = syncInstanceFromEvogo();
        $selected = null;
        foreach ($sync['instances'] ?? [] as $instance) {
            if (($instance['id'] ?? '') === $instanceId) {
                $selected = $instance;
                break;
            }
        }

        if ($selected === null) {
            jsonError('Instância não encontrada', 404);
        }

        $saved = saveConfig([
            'instance_id' => $selected['id'],
            'instance_token' => $selected['token'],
            'instance_name' => $selected['name'],
        ]);

        jsonResponse([
            'success' => true,
            'selected' => [
                'id' => $selected['id'],
                'name' => $selected['name'],
                'connected' => (bool) $selected['connected'],
            ],
            'config' => sanitizeConfig($saved),
        ]);
        break;

    case 'groups':
        $allInstances = ($_GET['all'] ?? '1') === '1';
        $filterInstanceId = $_GET['instance_id'] ?? '';

        $result = fetchAllInstanceGroups($allInstances, $filterInstanceId);
        if (!$result['success']) {
            jsonError($result['error'] ?? 'Falha ao listar grupos', 500, $result);
        }

        jsonResponse([
            'success' => true,
            'count' => $result['count'],
            'groups' => $result['groups'],
            'warnings' => $result['warnings'] ?? [],
            'instances' => $result['instances'] ?? [],
        ]);
        break;

    case 'group-meta':
        $body = getRequestBody();
        $jid = $body['jid'] ?? '';
        if ($jid === '') {
            jsonError('jid é obrigatório');
        }

        $meta = getGroupsMeta();
        $current = $meta[$jid] ?? [];
        $meta[$jid] = array_merge($current, array_intersect_key($body, array_flip(['tags', 'notes', 'enabled', 'alias', 'color'])));
        saveGroupsMeta($meta);

        jsonResponse(['success' => true, 'meta' => $meta[$jid]]);
        break;

    case 'group-action':
        $body = getRequestBody();
        $actionType = $body['action'] ?? '';
        $groupJid = $body['group_jid'] ?? '';
        $instanceId = $body['instance_id'] ?? '';

        if ($groupJid === '' || $actionType === '') {
            jsonError('action e group_jid são obrigatórios');
        }

        $client = clientForInstance($instanceId);
        $result = match ($actionType) {
            'info' => $client->getGroupInfo($groupJid),
            'name' => $client->setGroupName($groupJid, (string) ($body['name'] ?? '')),
            'description' => $client->setGroupDescription($groupJid, (string) ($body['description'] ?? '')),
            'invitelink' => $client->getInviteLink($groupJid, (bool) ($body['reset'] ?? false)),
            default => null,
        };

        if ($result === null) {
            jsonError('Ação inválida');
        }

        if (!$result['success']) {
            jsonError($result['error'] ?? 'Falha na ação', 500, $result);
        }

        jsonResponse(['success' => true, 'data' => $result['data']]);
        break;

    case 'messages-list':
        jsonResponse(['success' => true, 'messages' => getMessages(), 'upload_limit' => uploadLimit()]);
        break;

    case 'messages-save':
        $body = getRequestBody();
        $messages = getMessages();
        $id = $body['id'] ?? generateId();
        $record = [
            'id' => $id,
            'title' => trim((string) ($body['title'] ?? 'Sem título')),
            'content' => (string) ($body['content'] ?? ''),
            'type' => $body['type'] ?? 'text',
            'media_url' => $body['media_url'] ?? '',
            'media_type' => $body['media_type'] ?? 'image',
            'media_id' => (string) ($body['media_id'] ?? ''),
            'media_name' => '',
            'mention_all' => (bool) ($body['mention_all'] ?? false),
            'button_enabled' => (bool) ($body['button_enabled'] ?? false),
            'button_type' => (string) ($body['button_type'] ?? 'reply'),
            'button_label' => (string) ($body['button_label'] ?? ''),
            'button_url' => (string) ($body['button_url'] ?? ''),
            'updated_at' => nowIso(),
        ];
        validateMessageMedia($record);
        validateMessageOptions($record);

        $found = false;
        foreach ($messages as $index => $message) {
            if (($message['id'] ?? '') === $id) {
                $messages[$index] = array_merge($message, $record, ['created_at' => $message['created_at'] ?? nowIso()]);
                $found = true;
                break;
            }
        }

        if (!$found) {
            $record['created_at'] = nowIso();
            $messages[] = $record;
        }

        saveMessages($messages);
        jsonResponse(['success' => true, 'message' => $record]);
        break;

    case 'messages-delete':
        $body = getRequestBody();
        $id = $body['id'] ?? '';
        if ($id === '') {
            jsonError('id é obrigatório');
        }

        foreach (getQueues() as $queue) {
            if (in_array($id, $queue['message_ids'], true)) jsonError('Esta mensagem está em uma fila. Remova-a da fila antes de excluir.', 409);
        }
        foreach (getSchedules() as $schedule) {
            if (($schedule['message_id'] ?? '') === $id && in_array($schedule['status'] ?? '', ['pending', 'running'], true)) jsonError('Esta mensagem está em um agendamento pendente. Exclua o agendamento antes de remover a mensagem.', 409);
        }
        $messages = array_values(array_filter(getMessages(), static fn ($m) => ($m['id'] ?? '') !== $id));
        saveMessages($messages);
        jsonResponse(['success' => true]);
        break;

    case 'schedules-list':
        jsonResponse(['success' => true, 'schedules' => getSchedules()]);
        break;

    case 'schedules-save':
        $body = getRequestBody();
        $schedules = getSchedules();
        $id = $body['id'] ?? generateId();
        $existing = findSchedule($id);

        $groupItems = normalizeGroupItems(
            $body['group_jids'] ?? [],
            $body['group_items'] ?? [],
            getConfig()['instance_id']
        );

        $record = [
            'id' => $id,
            'title' => trim((string) ($body['title'] ?? 'Campanha')),
            'message_id' => (string) ($body['message_id'] ?? ''),
            'group_jids' => array_values(array_unique(array_column($groupItems, 'jid'))),
            'group_items' => $groupItems,
            'scheduled_at' => (string) ($body['scheduled_at'] ?? ''),
            'mention_all' => (bool) ($body['mention_all'] ?? false),
            'status' => $body['status'] ?? 'pending',
            'updated_at' => nowIso(),
        ];

        if ($record['message_id'] === '' || $record['scheduled_at'] === '' || count($record['group_items']) === 0) {
            jsonError('Preencha mensagem, data/hora e grupos');
        }

        if (!findMessage($record['message_id'])) jsonError('Mensagem não encontrada.', 404);
        try { $date = new DateTimeImmutable($record['scheduled_at'], new DateTimeZone(getConfig()['timezone'])); }
        catch (Exception $e) { jsonError('Data ou fuso horário inválido.'); }
        if ($date <= new DateTimeImmutable('+1 minute')) jsonError('Agende com pelo menos um minuto de antecedência.');
        $record['scheduled_at'] = $date->format(DateTimeInterface::ATOM);
        $record['status'] = 'pending';
        if ($existing !== null) {
            if ($existing['status'] !== 'pending') jsonError('Somente agendamentos pendentes podem ser editados.', 409);
            $record['cron_job_id'] = $existing['cron_job_id'] ?? null;
        }

        $cronJobId = registerCronJobForSchedule($record);
        if ($cronJobId) {
            $record['cron_job_id'] = $cronJobId;
        }

        $found = false;
        foreach ($schedules as $index => $schedule) {
            if (($schedule['id'] ?? '') === $id) {
                $schedules[$index] = array_merge($schedule, $record, ['created_at' => $schedule['created_at'] ?? nowIso()]);
                $found = true;
                break;
            }
        }

        if (!$found) {
            $record['created_at'] = nowIso();
            $schedules[] = $record;
        }

        saveSchedules($schedules);
        jsonResponse(['success' => true, 'schedule' => findSchedule($id)]);
        break;

    case 'schedules-delete':
        $body = getRequestBody();
        $id = $body['id'] ?? '';
        if ($id === '') {
            jsonError('id é obrigatório');
        }

        $schedule = findSchedule($id);
        if ($schedule !== null) {
            deleteCronJobForSchedule($schedule);
        }

        $schedules = array_values(array_filter(getSchedules(), static fn ($s) => ($s['id'] ?? '') !== $id));
        saveSchedules($schedules);
        jsonResponse(['success' => true]);
        break;

    case 'send-now':
        $body = getRequestBody();
        $messageId = $body['message_id'] ?? '';
        $groupItems = normalizeGroupItems(
            $body['group_jids'] ?? [],
            $body['group_items'] ?? [],
            getConfig()['instance_id']
        );

        if ($messageId === '' || count($groupItems) === 0) {
            jsonError('message_id e grupos são obrigatórios');
        }

        $schedule = [
            'id' => 'instant-' . generateId(),
            'title' => $body['title'] ?? 'Envio imediato',
            'message_id' => $messageId,
            'group_jids' => array_column($groupItems, 'jid'),
            'group_items' => $groupItems,
            'mention_all' => (bool) ($body['mention_all'] ?? false),
            'status' => 'pending',
        ];

        $result = executeBroadcast($schedule, true);
        jsonResponse($result, $result['success'] ? 200 : 500);
        break;

    case 'process-due':
        $processed = processDueSchedules();
        jsonResponse(['success' => true, 'processed' => count($processed), 'results' => $processed]);
        break;

    case 'logs':
        jsonResponse(['success' => true, 'logs' => getLogs(), 'heartbeat'=>storageRead('cron-heartbeat',null), 'server_time'=>nowIso()]);
        break;

    case 'webhook-url':
        jsonResponse([
            'success' => true,
            'url' => buildDispatchUrl('{id}'),
            'dispatch_example' => buildDispatchUrl('exemplo'),
        ]);
        break;

    default:
        jsonError('Ação inválida', 404);
}
