<?php
declare(strict_types=1);

function database(): PDO
{
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;
    $configPath = getenv('GRUPOS_DB_CONFIG') ?: __DIR__ . '/../data/database.php';
    if (!is_file($configPath)) throw new RuntimeException('Configure o MySQL e execute a migração pelo servidor.');
    $cfg = require $configPath;
    try {
        $pdo = new PDO('mysql:host=' . $cfg['host'] . ';port=' . ($cfg['port'] ?? 3306) . ';dbname=' . $cfg['database'] . ';charset=utf8mb4', $cfg['username'], $cfg['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);
    } catch (PDOException $e) {
        throw new RuntimeException('Não foi possível conectar ao MySQL. Verifique a configuração do servidor.');
    }
    return $pdo;
}

function storageTable(string $name): string
{
    return match ($name) {
        'messages' => 'messages', 'schedules' => 'schedules', 'queues' => 'queues',
        'groups-meta' => 'group_metadata', 'logs' => 'activity_logs',
        default => 'app_settings',
    };
}

function storageRead(string $name, mixed $default = []): mixed
{
    $pdo = database(); $table = storageTable($name);
    if ($table === 'app_settings') {
        $stmt = $pdo->prepare('SELECT payload FROM app_settings WHERE record_key = ?');
        $stmt->execute([$name]); $value = $stmt->fetchColumn();
        return $value === false ? $default : json_decode($value, true, 512, JSON_THROW_ON_ERROR);
    }
    $rows = $pdo->query("SELECT record_key, payload FROM `$table` ORDER BY sort_order, record_key")->fetchAll(PDO::FETCH_ASSOC);
    $result = [];
    foreach ($rows as $row) {
        $value = json_decode($row['payload'], true, 512, JSON_THROW_ON_ERROR);
        if ($name === 'groups-meta') $result[$row['record_key']] = $value;
        else $result[] = $value;
    }
    return $result;
}

function storageWrite(string $name, mixed $value): void
{
    $pdo = database(); $table = storageTable($name);
    if ($table === 'app_settings') {
        $stmt = $pdo->prepare('INSERT INTO app_settings (record_key,payload) VALUES (?,?) ON DUPLICATE KEY UPDATE payload=VALUES(payload)');
        $stmt->execute([$name, json_encode($value, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
        return;
    }
    $ownTransaction = !$pdo->inTransaction();
    if ($ownTransaction) $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM `$table`");
        $stmt = $pdo->prepare("INSERT INTO `$table` (record_key,payload,sort_order) VALUES (?,?,?)");
        $position = 0;
        foreach ($value as $key => $row) {
            $id = $name === 'groups-meta' ? (string) $key : (string) ($row['id'] ?? $key);
            $stmt->execute([$id, json_encode($row, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), $position++]);
        }
        if ($ownTransaction) $pdo->commit();
    } catch (Throwable $e) {
        if ($ownTransaction && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function databaseLock(string $name, int $timeout = 30): void
{
    $pdo = database();
    $lock = 'grupos:' . $pdo->query('SELECT DATABASE()')->fetchColumn() . ':' . $name;
    $stmt = $pdo->prepare('SELECT GET_LOCK(?, ?)'); $stmt->execute([$lock, $timeout]);
    if ((int) $stmt->fetchColumn() !== 1) throw new RuntimeException('Outro processamento está em andamento. Tente novamente.');
    register_shutdown_function(static function () use ($pdo, $lock) {
        try { $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)'); $stmt->execute([$lock]); } catch (Throwable $e) {}
    });
}

function databaseUnlock(string $name): void
{
    $pdo = database();
    $lock = 'grupos:' . $pdo->query('SELECT DATABASE()')->fetchColumn() . ':' . $name;
    $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)'); $stmt->execute([$lock]);
}
