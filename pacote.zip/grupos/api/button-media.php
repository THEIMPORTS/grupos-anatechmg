<?php
declare(strict_types=1);
require_once __DIR__ . '/media.php';
$id = (string) ($_GET['id'] ?? '');
$expires = (string) ($_GET['expires'] ?? '');
$signature = (string) ($_GET['signature'] ?? '');
if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !ctype_digit($expires) || (int) $expires < time() || (int) $expires > time() + 300 || !hash_equals(hash_hmac('sha256', $id . ':' . $expires, getConfig()['webhook_secret']), $signature)) jsonError('Link inválido ou expirado.', 403);
serveMedia($id);
