<?php

declare(strict_types=1);

require_once __DIR__ . '/cronjob-client.php';
require_once __DIR__ . '/media.php';
require_once __DIR__ . '/message-options.php';

function sendSavedMessage(EvogoClient $client, string $groupJid, array $message, bool $mentionAll = false): array
{
    $mentionAll = $mentionAll || !empty($message['mention_all']);
    if (!empty($message['button_enabled'])) return sendButtonMessage($client, $groupJid, $message, $mentionAll);
    if (($message['type'] ?? 'text') === 'media') {
        if (!empty($message['media_id'])) {
            $media = findMedia($message['media_id']);
            if (!$media) throw new RuntimeException('Arquivo da mensagem não encontrado.');
            return $client->sendMediaFile($groupJid, $media, $message['content'] ?? '', $mentionAll);
        }
        if (empty($message['media_url'])) throw new RuntimeException('Mensagem sem arquivo ou URL de mídia.');
        $url = (string) $message['media_url'];
        $tmp = tempnam(sys_get_temp_dir(), 'evogo-media-');
        if ($tmp === false) throw new RuntimeException('Não foi possível preparar a mídia.');
        try {
            $body = @file_get_contents($url);
            if ($body === false || $body === '') throw new RuntimeException('A URL da mídia não retornou um arquivo válido.');
            file_put_contents($tmp, $body);
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: '';
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!isset($allowed[$mime])) throw new RuntimeException("A URL da mídia retornou {$mime}, formato não aceito.");
            return $client->sendMediaBinary($groupJid, $tmp, 'imagem.' . $allowed[$mime], $mime, $message['media_type'] ?? 'image', $message['content'] ?? '', $mentionAll);
        } finally { @unlink($tmp); }
    }
    return $client->sendText($groupJid, $message['content'] ?? '', ['mentionAll' => $mentionAll]);
}

const MESSAGES_FILE = DATA_DIR . '/messages.json';
const SCHEDULES_FILE = DATA_DIR . '/schedules.json';
const GROUPS_META_FILE = DATA_DIR . '/groups-meta.json';
const LOGS_FILE = DATA_DIR . '/logs.json';

function getMessages(): array
{
    return storageRead('messages', []);
}

function saveMessages(array $messages): void
{
    storageWrite('messages', $messages);
}

function getSchedules(): array
{
    return storageRead('schedules', []);
}

function saveSchedules(array $schedules): void
{
    storageWrite('schedules', $schedules);
}

function getGroupsMeta(): array
{
    return storageRead('groups-meta', []);
}

function saveGroupsMeta(array $meta): void
{
    storageWrite('groups-meta', $meta);
}

function appendLog(array $entry): void
{
    if (isset($entry['detail'])) $entry['detail'] = safeLogDetail($entry['detail']);
    $logs = storageRead('logs', []);
    array_unshift($logs, array_merge([
        'id' => generateId(),
        'created_at' => nowIso(),
    ], $entry));
    $logs = array_slice($logs, 0, 200);
    storageWrite('logs', $logs);
}

function safeLogDetail(mixed $detail): string
{
    $text = is_string($detail) ? $detail : json_encode($detail, JSON_UNESCAPED_UNICODE);
    foreach (getConfig() as $key => $value) {
        if (is_string($value) && strlen($value) > 5 && preg_match('/key|token|secret/', $key)) $text = str_replace($value, '[oculto]', $text);
    }
    $text = preg_replace('/(signature|secret|apikey|token)=([^&\s]+)/i', '$1=[oculto]', $text);
    return substr($text, 0, 2000);
}

function getLogs(): array
{
    return storageRead('logs', []);
}

function findMessage(string $id): ?array
{
    foreach (getMessages() as $message) {
        if (($message['id'] ?? '') === $id) {
            return $message;
        }
    }

    return null;
}

function findSchedule(string $id): ?array
{
    foreach (getSchedules() as $schedule) {
        if (($schedule['id'] ?? '') === $id) {
            return $schedule;
        }
    }

    return null;
}

function updateSchedule(string $id, array $changes): ?array
{
    $schedules = getSchedules();
    $updated = null;

    foreach ($schedules as $index => $schedule) {
        if (($schedule['id'] ?? '') !== $id) {
            continue;
        }

        $schedules[$index] = array_merge($schedule, $changes, ['updated_at' => nowIso()]);
        $updated = $schedules[$index];
        break;
    }

    if ($updated === null) {
        return null;
    }

    saveSchedules($schedules);
    return $updated;
}

function executeBroadcast(array $schedule, bool $force = false): array
{
    $config = getConfig();

    if (!$force && ($schedule['status'] ?? '') !== 'pending') {
        return ['success' => false, 'error' => 'Agendamento não está pendente'];
    }

    $message = findMessage($schedule['message_id'] ?? '');
    if ($message === null) {
        updateSchedule($schedule['id'], ['status' => 'failed', 'error' => 'Mensagem não encontrada']);
        return ['success' => false, 'error' => 'Mensagem não encontrada'];
    }

    $groupItems = normalizeGroupItems(
        $schedule['group_jids'] ?? [],
        $schedule['group_items'] ?? [],
        $config['instance_id']
    );

    if (count($groupItems) === 0) {
        updateSchedule($schedule['id'], ['status' => 'failed', 'error' => 'Nenhum grupo selecionado']);
        return ['success' => false, 'error' => 'Nenhum grupo selecionado'];
    }

    if (($schedule['id'] ?? '') !== '' && !str_starts_with((string) $schedule['id'], 'instant-')) {
        updateSchedule($schedule['id'], ['status' => 'running', 'started_at' => nowIso()]);
    }

    $minDelay = max(1, (int) ($config['send_delay_min_seconds'] ?? $config['send_delay_seconds'] ?? 4));
    $maxDelay = max($minDelay, (int) ($config['send_delay_max_seconds'] ?? $minDelay));
    $results = [];
    $failures = 0;
    $sendIndex = 0;

    foreach ($groupItems as $item) {
        if ($sendIndex > 0) {
            sleep($maxDelay > $minDelay ? random_int($minDelay, $maxDelay) : $minDelay);
        }

        $groupJid = $item['jid'];
        try {
            $client = clientForInstance($item['instance_id'] ?? '');
            $result = sendSavedMessage($client, $groupJid, $message, (bool) ($schedule['mention_all'] ?? false));
        } catch (Throwable $e) { $result = ['success'=>false,'error'=>safeLogDetail($e->getMessage()),'status'=>0]; }
        appendLog(['type'=>'send','title'=>$message['title'] ?? 'Envio', 'status'=>!empty($result['success'])?'completed':'failed','group_jid'=>$groupJid,'instance_id'=>$item['instance_id']??'', 'detail'=>!empty($result['success'])?'Evolution GO confirmou o envio.':'HTTP ' . ($result['status']??0) . ': ' . safeLogDetail($result['error']??'Envio não confirmado')]);

        $ok = (bool) $result['success'];
        if (!$ok) {
            $failures++;
        }

        $results[] = [
            'group_jid' => $groupJid,
            'instance_id' => $item['instance_id'] ?? '',
            'success' => $ok,
            'error' => $result['error'] ?? null,
        ];

        $sendIndex++;
    }

    $status = $failures === 0 ? 'completed' : ($failures === count($groupItems) ? 'failed' : 'partial');
    $summary = [
        'status' => $status,
        'finished_at' => nowIso(),
        'results' => $results,
        'failures' => $failures,
        'total' => count($groupItems),
    ];

    if (($schedule['id'] ?? '') !== '' && !str_starts_with((string) $schedule['id'], 'instant-')) {
        updateSchedule($schedule['id'], $summary);
    }

    appendLog([
        'type' => 'broadcast',
        'schedule_id' => $schedule['id'] ?? '',
        'title' => $schedule['title'] ?? '',
        'status' => $status,
        'groups' => count($groupItems),
        'failures' => $failures,
    ]);

    return [
        'success' => $status !== 'failed',
        'status' => $status,
        'results' => $results,
    ];
}

function processDueSchedules(): array
{
    $now = new DateTimeImmutable('now', new DateTimeZone(getConfig()['timezone']));
    $processed = [];

    foreach (getSchedules() as $schedule) {
        if (($schedule['status'] ?? '') !== 'pending') {
            continue;
        }

        $scheduledAt = $schedule['scheduled_at'] ?? '';
        if ($scheduledAt === '') {
            continue;
        }

        $target = new DateTimeImmutable($scheduledAt, new DateTimeZone(getConfig()['timezone']));
        if ($target > $now) {
            continue;
        }

        $processed[] = executeBroadcast($schedule);
    }

    return $processed;
}
