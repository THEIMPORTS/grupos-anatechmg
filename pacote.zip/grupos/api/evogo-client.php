<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

class EvogoClient
{
    public function __construct(
        private readonly string $baseUrl,
        private readonly string $apiKey
    ) {
    }

    public static function forInstance(string $baseUrl, string $token): self
    {
        return new self(rtrim($baseUrl, '/'), $token);
    }

    public static function fromConfig(?array $config = null): self
    {
        $config ??= getConfig();
        $key = $config['instance_token'] ?: $config['global_api_key'];
        return new self(rtrim($config['evogo_base_url'], '/'), $key);
    }

    public static function globalFromConfig(?array $config = null): self
    {
        $config ??= getConfig();
        return new self(rtrim($config['evogo_base_url'], '/'), $config['global_api_key']);
    }

    public function request(string $method, string $path, ?array $body = null): array
    {
        $url = $this->baseUrl . $path;
        $ch = curl_init($url);

        $multipart = $body !== null && isset($body['file']) && $body['file'] instanceof CURLFile;
        $headers = [
            'apikey: ' . $this->apiKey,
            ...($multipart ? [] : ['Content-Type: application/json']),
            'Accept: application/json',
        ];

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_CONNECTTIMEOUT => 20,
        ]);

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $multipart ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
        }

        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return [
                'success' => false,
                'status' => 0,
                'error' => $error ?: 'Falha na conexão com a API Evogo',
                'data' => null,
            ];
        }

        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            return [
                'success' => false,
                'status' => $status,
                'error' => 'Resposta inválida da API',
                'data' => $response,
            ];
        }

        $ok = $status >= 200 && $status < 300 && !isset($decoded['error']);

        return [
            'success' => $ok,
            'status' => $status,
            'error' => $decoded['error'] ?? ($ok ? null : 'Erro na API'),
            'data' => $decoded,
        ];
    }

    public function getInstances(): array
    {
        return self::globalFromConfig()->request('GET', '/instance/all');
    }

    public function listGroups(): array
    {
        return $this->request('GET', '/group/list');
    }

    public function getGroupInfo(string $groupJid): array
    {
        return $this->request('POST', '/group/info', ['groupJid' => $groupJid]);
    }

    public function setGroupName(string $groupJid, string $name): array
    {
        return $this->request('POST', '/group/name', ['groupJid' => $groupJid, 'name' => $name]);
    }

    public function setGroupDescription(string $groupJid, string $description): array
    {
        return $this->request('POST', '/group/description', ['groupJid' => $groupJid, 'description' => $description]);
    }

    public function getInviteLink(string $groupJid, bool $reset = false): array
    {
        return $this->request('POST', '/group/invitelink', ['groupJid' => $groupJid, 'reset' => $reset]);
    }

    public function sendText(string $groupJid, string $text, array $options = []): array
    {
        $payload = array_merge([
            'number' => $groupJid,
            'text' => $text,
        ], $options);

        return $this->request('POST', '/send/text', $payload);
    }

    public function sendMedia(string $groupJid, string $mediaUrl, string $caption = '', string $mediatype = 'image', bool $mentionAll = false): array
    {
        return $this->request('POST', '/send/media', [
            'number' => $groupJid,
            'url' => $mediaUrl,
            'caption' => $caption,
            'type' => $mediatype,
            'mentionAll' => $mentionAll,
        ]);
    }

    public function sendMediaFile(string $groupJid, array $media, string $caption, bool $mentionAll = false): array
    {
        return $this->request('POST', '/send/media', [
            'number' => $groupJid, 'type' => $media['type'], 'caption' => $caption,
            'filename' => $media['name'], 'mentionAll' => $mentionAll ? 'true' : 'false',
            'file' => new CURLFile(DATA_DIR . '/media/' . $media['id'] . '.bin', $media['mime'], $media['name']),
        ]);
    }

    public function sendMediaBinary(string $groupJid, string $path, string $name, string $mime, string $type, string $caption = '', bool $mentionAll = false): array
    {
        return $this->request('POST', '/send/media', [
            'number' => $groupJid, 'type' => $type, 'caption' => $caption,
            'filename' => $name, 'mentionAll' => $mentionAll ? 'true' : 'false',
            'file' => new CURLFile($path, $mime, $name),
        ]);
    }
}

function syncInstanceFromEvogo(): array
{
    $client = EvogoClient::globalFromConfig();
    $result = $client->getInstances();

    if (!$result['success']) {
        return $result;
    }

    $instances = $result['data']['data'] ?? [];
    if (!is_array($instances) || count($instances) === 0) {
        return ['success' => false, 'error' => 'Nenhuma instância encontrada na Evogo'];
    }

    $config = getConfig();
    $selected = null;

    if ($config['instance_id'] !== '') {
        foreach ($instances as $instance) {
            if (($instance['id'] ?? '') === $config['instance_id']) {
                $selected = $instance;
                break;
            }
        }
    }

    if ($selected === null) {
        foreach ($instances as $instance) {
            if (!empty($instance['connected'])) {
                $selected = $instance;
                break;
            }
        }
    }

    $selected ??= $instances[0];

    $updated = saveConfig([
        'instance_id' => $selected['id'] ?? '',
        'instance_token' => $selected['token'] ?? '',
        'instance_name' => $selected['name'] ?? '',
    ]);

    return [
        'success' => true,
        'instances' => $instances,
        'selected' => $selected,
        'config' => sanitizeConfig($updated),
    ];
}

function extractPhoneDigits(string $jid): string
{
    $local = explode('@', $jid)[0] ?? $jid;
    $local = preg_replace('/:.*/', '', $local);

    return preg_replace('/\D/', '', $local);
}

function participantMatchesInstance(array $participant, string $instanceJid): bool
{
    if ($instanceJid === '') {
        return false;
    }

    $participantJid = $participant['JID'] ?? '';
    $participantLid = $participant['LID'] ?? '';
    $participantPhone = $participant['PhoneNumber'] ?? '';

    if (in_array($instanceJid, [$participantJid, $participantLid, $participantPhone], true)) {
        return true;
    }

    $instanceDigits = extractPhoneDigits($instanceJid);
    $phoneDigits = extractPhoneDigits($participantPhone);

    if ($instanceDigits === '' || $phoneDigits === '') {
        return false;
    }

    return str_ends_with($phoneDigits, $instanceDigits) || str_ends_with($instanceDigits, $phoneDigits);
}

function getGroupAdminStatus(array $group, string $instanceJid): array
{
    foreach ($group['Participants'] ?? [] as $participant) {
        if (!participantMatchesInstance($participant, $instanceJid)) {
            continue;
        }

        return [
            'is_admin' => !empty($participant['IsAdmin']) || !empty($participant['IsSuperAdmin']),
            'is_super_admin' => !empty($participant['IsSuperAdmin']),
        ];
    }

    return ['is_admin' => false, 'is_super_admin' => false];
}

function mapGroupForApi(array $group, array $instance, array $meta): array
{
    $jid = $group['JID'] ?? '';
    $local = $meta[$jid] ?? [];
    $admin = getGroupAdminStatus($group, $instance['jid'] ?? '');

    return [
        'jid' => $jid,
        'instance_id' => $instance['id'] ?? '',
        'instance_name' => $instance['name'] ?? '',
        'name' => $group['Name'] ?? '',
        'topic' => $group['Topic'] ?? '',
        'participants_count' => is_array($group['Participants'] ?? null)
            ? count($group['Participants'])
            : (int) ($group['ParticipantCount'] ?? 0),
        'is_announce' => (bool) ($group['IsAnnounce'] ?? false),
        'is_locked' => (bool) ($group['IsLocked'] ?? false),
        'is_admin' => $admin['is_admin'],
        'is_super_admin' => $admin['is_super_admin'],
        'meta' => array_merge([
            'tags' => [],
            'notes' => '',
            'enabled' => true,
            'alias' => '',
            'color' => '#22c55e',
        ], $local),
    ];
}

function clientForInstance(string $instanceId, ?array $instances = null): EvogoClient
{
    $config = getConfig();

    if ($instanceId === '' || $instanceId === $config['instance_id']) {
        return EvogoClient::fromConfig($config);
    }

    if ($instances === null) {
        $sync = syncInstanceFromEvogo();
        $instances = $sync['instances'] ?? [];
    }

    foreach ($instances as $instance) {
        if (($instance['id'] ?? '') === $instanceId && !empty($instance['token'])) {
            return EvogoClient::forInstance($config['evogo_base_url'], $instance['token']);
        }
    }

    throw new RuntimeException('Instância solicitada não está disponível. Sincronize as instâncias.');
}

function fetchInstanceGroups(array $instance, array $meta, string $baseUrl): array
{
    if (empty($instance['token']) || empty($instance['connected'])) {
        return [];
    }

    $client = EvogoClient::forInstance($baseUrl, $instance['token']);
    $result = $client->listGroups();

    if (!$result['success']) {
        throw new RuntimeException('Falha ao carregar grupos da instância ' . ($instance['name'] ?? '') . '. Verifique a conexão no Evolution GO.');
    }

    $groups = $result['data']['data'] ?? [];

    return array_map(
        static fn (array $group) => mapGroupForApi($group, $instance, $meta),
        is_array($groups) ? $groups : []
    );
}

function fetchAllInstanceGroups(bool $allInstances = true, string $filterInstanceId = ''): array
{
    $sync = syncInstanceFromEvogo();
    if (!$sync['success']) {
        return $sync;
    }

    $config = getConfig();
    $meta = getGroupsMeta();
    $managed = array_values(array_map('strval', (array) ($config['managed_instance_ids'] ?? [])));
    $managedNames = array_values(array_map('strval', array_column((array) ($config['managed_instances'] ?? []), 'name')));
    $instances = array_values(array_filter($sync['instances'] ?? [], static fn($i) => in_array((string)($i['id'] ?? ''), $managed, true) || in_array((string)($i['name'] ?? ''), $managedNames, true)));
    $merged = [];

    if ($filterInstanceId !== '') {
        foreach ($instances as $instance) {
            if (($instance['id'] ?? '') === $filterInstanceId) {
                $merged = fetchInstanceGroups($instance, $meta, $config['evogo_base_url']);
                break;
            }
        }
    } elseif ($allInstances) {
        $warnings = [];
        foreach ($instances as $instance) {
            try { $merged = array_merge($merged, fetchInstanceGroups($instance, $meta, $config['evogo_base_url'])); }
            catch (Throwable $e) { $warnings[] = $e->getMessage(); }
        }
    } else {
        $selected = $sync['selected'] ?? null;
        if ($selected !== null) {
            $merged = fetchInstanceGroups($selected, $meta, $config['evogo_base_url']);
        }
    }

    usort($merged, static function (array $a, array $b): int {
        $byInstance = strcasecmp($a['instance_name'], $b['instance_name']);
        return $byInstance !== 0 ? $byInstance : strcasecmp($a['name'], $b['name']);
    });

    return [
        'success' => true,
        'count' => count($merged),
        'groups' => $merged,
        'warnings' => $warnings ?? [],
        'instances' => array_map(static fn (array $i) => [
            'id' => $i['id'] ?? '',
            'name' => $i['name'] ?? '',
            'connected' => (bool) ($i['connected'] ?? false),
        ], $instances),
    ];
}

function normalizeGroupItems(array $groupJids, array $groupItems, string $defaultInstanceId): array
{
    if (count($groupItems) > 0) {
        return array_values(array_filter(array_map(static function ($item) {
            if (!is_array($item)) {
                return null;
            }

            $jid = $item['jid'] ?? '';
            $instanceId = $item['instance_id'] ?? '';

            if ($jid === '') {
                return null;
            }

            return ['jid' => $jid, 'instance_id' => $instanceId];
        }, $groupItems)));
    }

    return array_map(
        static fn (string $jid) => ['jid' => $jid, 'instance_id' => $defaultInstanceId],
        $groupJids
    );
}

function sanitizeConfig(array $config): array
{
    return [
        'evogo_base_url' => $config['evogo_base_url'],
        'global_api_key' => maskSecret($config['global_api_key']),
        'instance_id' => $config['instance_id'],
        'instance_token' => maskSecret($config['instance_token']),
        'instance_name' => $config['instance_name'],
        'send_delay_seconds' => (int) $config['send_delay_seconds'],
        'webhook_secret' => $config['webhook_secret'],
        'cronjob_api_key' => maskSecret($config['cronjob_api_key']),
        'openai_api_key' => empty($config['openai_api_key']) ? '' : '********',
        'public_webhook_url' => $config['public_webhook_url'],
        'timezone' => $config['timezone'],
    ];
}

function maskSecret(string $value): string
{
    if ($value === '') {
        return '';
    }

    if (strlen($value) <= 8) {
        return '********';
    }

    return substr($value, 0, 4) . str_repeat('*', max(4, strlen($value) - 8)) . substr($value, -4);
}
