<?php
declare(strict_types=1);
header('Cache-Control: no-store');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
ini_set('display_errors', '0');
session_name('grupos_installer');
session_set_cookie_params(['httponly'=>true, 'samesite'=>'Strict', 'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off']);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$dataDir = __DIR__ . '/data';
$installed = is_file($dataDir . '/database.php') || is_file($dataDir . '/installed.lock') || (bool) getenv('GRUPOS_DB_CONFIG');
$checks = ['PHP 8.1 ou superior' => PHP_VERSION_ID >= 80100, 'PDO MySQL' => extension_loaded('pdo_mysql'), 'cURL' => extension_loaded('curl'), 'Fileinfo' => extension_loaded('fileinfo'), 'ZIP' => extension_loaded('zip'), 'Pasta data gravável' => is_dir($dataDir) && is_writable($dataDir)];
$error = ''; $success = false;
function h(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    $lock = null; $pdo = null; $published = false;
    try {
        if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('Sessão expirada. Recarregue a página.');
        if (in_array(false, $checks, true)) throw new RuntimeException('Corrija os requisitos indicados antes de instalar.');
        $tokenFile = $dataDir . '/install-token.php';
        if (!is_file($tokenFile) || !password_verify((string) ($_POST['install_code'] ?? ''), require $tokenFile)) throw new RuntimeException('Código de instalação inválido. Use o código entregue com o pacote.');
        $lock = fopen($dataDir . '/install.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) throw new RuntimeException('Outra instalação está em andamento.');
        clearstatcache();
        if (is_file($dataDir . '/database.php') || is_file($dataDir . '/installed.lock')) throw new RuntimeException('O sistema já foi instalado.');
        $host = trim((string) ($_POST['db_host'] ?? ''));
        $port = filter_var($_POST['db_port'] ?? '', FILTER_VALIDATE_INT);
        $name = trim((string) ($_POST['db_name'] ?? ''));
        $user = trim((string) ($_POST['db_user'] ?? ''));
        $password = (string) ($_POST['db_password'] ?? '');
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $adminPassword = (string) ($_POST['admin_password'] ?? '');
        $publicUrl = rtrim(trim((string) ($_POST['public_url'] ?? '')), '/');
        if (!preg_match('/^[a-zA-Z0-9._:-]+$/D', $host) || !$port || $port < 1 || $port > 65535 || !preg_match('/^[a-zA-Z0-9_-]+$/D', $name) || $user === '') throw new RuntimeException('Confira host, porta, nome e usuário do MySQL.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($adminPassword) < 12 || $adminPassword !== ($_POST['password_confirm'] ?? '')) throw new RuntimeException('Informe e-mail válido e senhas iguais com pelo menos 12 caracteres.');
        if (!filter_var($publicUrl, FILTER_VALIDATE_URL) || parse_url($publicUrl, PHP_URL_SCHEME) !== 'https' || parse_url($publicUrl, PHP_URL_QUERY) || parse_url($publicUrl, PHP_URL_FRAGMENT) || parse_url($publicUrl, PHP_URL_USER)) throw new RuntimeException('Informe a URL HTTPS do sistema, incluindo a subpasta, se houver.');
        try { $pdo = new PDO("mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4", $user, $password, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES=>false]); }
        catch (PDOException $e) { throw new RuntimeException('Não foi possível conectar. Confira os dados e as permissões do usuário no painel da hospedagem.'); }
        $dbLock = $pdo->prepare('SELECT GET_LOCK(?, 0)'); $dbLock->execute(['grupos-install:' . $name]);
        if ((int) $dbLock->fetchColumn() !== 1) throw new RuntimeException('O banco está sendo instalado em outra sessão.');
        $tables = ['app_settings','messages','schedules','queues','group_metadata','activity_logs'];
        $existing = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($existing as $table) {
            if (!in_array($table, $tables, true) || (int) $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn() > 0) throw new RuntimeException('Use um banco vazio exclusivo. O instalador não sobrescreve dados existentes.');
        }
        require_once __DIR__ . '/api/schema.php';
        createSchema($pdo);
        $cfg = ['host'=>$host,'port'=>$port,'database'=>$name,'username'=>$user,'password'=>$password];
        $phpConfig = "<?php\nif (PHP_SAPI !== 'cli' && realpath(\$_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) { http_response_code(404); exit; }\nreturn " . var_export($cfg, true) . ";\n";
        $temporary = $dataDir . '/database-pending.php';
        if (file_put_contents($temporary, $phpConfig, LOCK_EX) === false) throw new RuntimeException('Falha ao gravar configuração do banco.');
        @chmod($temporary, 0600);
        $pdo->beginTransaction();
        $insert = $pdo->prepare('INSERT INTO app_settings (record_key,payload) VALUES (?,?)');
        $insert->execute(['admin', json_encode(['email'=>$email,'hash'=>password_hash($adminPassword,PASSWORD_DEFAULT)], JSON_THROW_ON_ERROR)]);
        $insert->execute(['config', json_encode(['public_webhook_url'=>$publicUrl,'timezone'=>'America/Fortaleza','webhook_secret'=>bin2hex(random_bytes(32))], JSON_THROW_ON_ERROR)]);
        $insert->execute(['mysql_migrated', json_encode(['at'=>date(DATE_ATOM),'fresh_install'=>true], JSON_THROW_ON_ERROR)]);
        if (!rename($temporary, $dataDir . '/database.php')) throw new RuntimeException('Não foi possível ativar a configuração.');
        $published = true;
        $pdo->commit();
        file_put_contents($dataDir . '/installed.lock', date(DATE_ATOM));
        @unlink($tokenFile);
        $success = true; $installed = true;
    } catch (Throwable $e) {
        if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
        if ($published) @unlink($dataDir . '/database.php');
        $error = $e instanceof PDOException ? 'Falha ao criar as tabelas. Verifique suporte a JSON, MySQL 8+ e permissões CREATE, SELECT, INSERT, UPDATE e DELETE.' : $e->getMessage();
    } finally {
        if (isset($temporary) && is_file($temporary)) @unlink($temporary);
        if (is_resource($lock)) { flock($lock, LOCK_UN); fclose($lock); }
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalação — Grupos ANATECH MG</title><link rel="stylesheet" href="assets/css/app.css"></head>
<body><main style="max-width:820px;margin:40px auto;padding:20px"><div class="panel"><div class="panel-header"><h1>Instalar Grupos ANATECH MG</h1></div><div class="panel-body">
<?php if ($installed): ?>
<h2><?= $success ? 'Instalação concluída' : 'Sistema já instalado' ?></h2><p><?= $success ? 'Seu administrador foi criado. Entre e configure as chaves Evolution GO, cron-job.org e OpenAI.' : 'O instalador está bloqueado para preservar seus dados.' ?></p><a class="btn btn-primary" href="./">Acessar sistema</a>
<?php else: ?>
<p>Crie primeiro um banco MySQL vazio e seu usuário no painel da hospedagem. Depois preencha os dados abaixo.</p>
<ul><?php foreach ($checks as $label=>$ok): ?><li><?= $ok ? '✓' : '✕' ?> <?= h($label) ?></li><?php endforeach; ?></ul>
<?php if ($error): ?><p role="alert" style="color:#fca5a5"><?= h($error) ?></p><?php endif; ?>
<form method="post" class="form" autocomplete="off"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<label>Código de instalação<input name="install_code" type="password" autocomplete="new-password" required></label>
<div class="form-grid"><label>Host MySQL<input name="db_host" value="localhost" required></label><label>Porta<input name="db_port" type="number" value="3306" required></label><label>Nome do banco<input name="db_name" required></label><label>Usuário MySQL<input name="db_user" required></label></div>
<label>Senha MySQL<input name="db_password" type="password" autocomplete="new-password"></label>
<label>URL pública deste sistema<input type="url" name="public_url" placeholder="https://seudominio.com/grupos" required></label>
<h2>Administrador</h2><label>E-mail<input type="email" name="email" required></label><div class="form-grid"><label>Senha (mínimo 12 caracteres)<input name="admin_password" type="password" minlength="12" autocomplete="new-password" required></label><label>Confirmar senha<input name="password_confirm" type="password" minlength="12" autocomplete="new-password" required></label></div>
<button class="btn btn-primary" type="submit" <?= in_array(false,$checks,true) ? 'disabled' : '' ?>>Instalar sistema</button></form>
<?php endif; ?></div></div></main></body></html>
