let ctx;
let savedMedia = null;
let localPreview = '';
let copyRevision = 0;
const el = (id) => document.getElementById(id);
const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export function resetCopyEditor() {
  copyRevision++;
  el('aiSummary').value = '';
  el('aiCopyText').value = '';
  el('aiCopyStatus').textContent = '';
  el('aiCopyResult').hidden = true;
}

export function resetMessageMedia(message) {
  if (localPreview) URL.revokeObjectURL(localPreview);
  localPreview = '';
  savedMedia = message?.media_id ? {id: message.media_id, name: message.media_name, type: message.media_type} : null;
  el('messageMediaFile').value = '';
  updateMessagePreview();
}

export function updateMessagePreview() {
  const root = el('messagePreview');
  if (!root) return;
  const isMedia = el('messageType').value === 'media';
  const buttonEnabled = el('messageButtonEnabled').checked;
  const linkButton = el('messageButtonType').value === 'url';
  el('messageButtonFields').hidden = !buttonEnabled;
  el('messageButtonUrlLabel').hidden = !linkButton;
  el('messageButtonUrl').required = buttonEnabled && linkButton;
  el('messageButtonUrl').disabled = !buttonEnabled || !linkButton;
  el('messageButtonLabel').required = buttonEnabled;
  const file = el('messageMediaFile').files[0];
  const type = file ? (file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'document') : savedMedia?.type || el('messageMediaType').value;
  const source = localPreview || (savedMedia ? `./api/index.php?action=media-file&id=${encodeURIComponent(savedMedia.id)}` : el('messageMediaUrl').value);
  el('mediaCurrentFile').textContent = file?.name || savedMedia?.name || 'Nenhum arquivo selecionado';
  el('messageContent').required = !isMedia || buttonEnabled;
  root.replaceChildren();
  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  if (isMedia && source) {
    if (type === 'image' || type === 'video') {
      const media = document.createElement(type === 'image' ? 'img' : 'video');
      if (/^(https?:|blob:|\.\/api\/index\.php\?action=media-file)/i.test(source)) media.src = source;
      if (type === 'video') { media.controls = true; media.preload = 'metadata'; }
      else { media.alt = 'Prévia da imagem selecionada'; media.referrerPolicy = 'no-referrer'; }
      media.onerror = () => {
        const error = document.createElement('p');
        error.className = 'message-file';
        error.textContent = 'Não foi possível carregar a prévia. Verifique a mídia.';
        media.replaceWith(error);
      };
      bubble.append(media);
    } else {
      const documentLabel = document.createElement('div');
      documentLabel.className = 'message-file';
      documentLabel.textContent = '📎 ' + (file?.name || savedMedia?.name || 'Documento');
      bubble.append(documentLabel);
    }
  }
  const caption = document.createElement('p');
  caption.className = 'message-caption';
  caption.textContent = el('messageContent').value || (isMedia ? 'Sua legenda aparece aqui…' : 'Sua mensagem aparece aqui…');
  bubble.append(caption);
  const time = document.createElement('small');
  time.className = 'preview-time';
  time.textContent = '12:00 ✓✓';
  bubble.append(time);
  if (buttonEnabled) {
    const action = document.createElement('div');
    action.className = 'preview-action';
    action.textContent = (linkButton ? '↗ ' : '↩ ') + (el('messageButtonLabel').value || 'Texto do botão');
    bubble.append(action);
  }
  root.append(bubble);
}

export async function messageMediaPayload() {
  if (el('messageType').value !== 'media') return {media_id: ''};
  const file = el('messageMediaFile').files[0];
  if (file) {
    if (file.size > ctx.state.uploadLimit) throw new Error('Arquivo acima do limite indicado no formulário.');
    const data = new FormData();
    data.append('file', file);
    const result = await ctx.api('media-upload', {method: 'POST', formData: data});
    savedMedia = result.media;
    el('messageMediaFile').value = '';
    if (localPreview) URL.revokeObjectURL(localPreview);
    localPreview = '';
    updateMessagePreview();
  }
  return {media_id: savedMedia?.id || '', ...(savedMedia ? {media_url: '', media_type: savedMedia.type} : {})};
}

function editQueue(queue) {
  el('queueForm').reset();
  el('queueId').value = queue?.id || '';
  el('queueTitle').value = queue?.title || '';
  el('queueStart').value = queue?.start_time || '08:00';
  el('queueEnd').value = queue?.end_time || '18:00';
  el('queueInterval').value = queue?.interval_minutes || 30;
  el('queueMode').value = queue?.schedule_mode || 'interval';
  el('queueTimes').value = (queue?.send_times || []).join(',');
  renderQueueTimes();
  el('queueMode').dispatchEvent(new Event('change'));
  refreshFeatures();
  const key = queue ? `${queue.group.instance_id}:${queue.group.jid}` : '';
  if (queue && !Array.from(el('queueGroup').options).some(o => o.value === key)) {
    el('queueGroup').add(new Option(queue.group.name + ' (não disponível na sincronização)', key));
  }
  el('queueGroup').value = key;
  el('queueDays').querySelectorAll('input').forEach(input => input.checked = (queue?.days || [1,2,3,4,5]).includes(Number(input.value)));
  el('queueProducts').querySelectorAll('input').forEach(input => input.checked = (queue?.message_ids || []).includes(input.value));
  el('queueTimezone').textContent = `Horários no fuso ${queue?.timezone || ctx.state.config?.timezone || 'America/Sao_Paulo'}.`;
}

export function refreshFeatures() {
  if (!ctx) return;
  const {state, escapeHtml: esc} = ctx;
  const selected = el('queueGroup').value;
  const existing = Array.from(el('queueGroup').options).find(o => o.value === selected);
  el('queueGroup').replaceChildren(new Option('Selecione o grupo', ''));
  const connection = el('queueConnection')?.value || '';
  state.groups.filter(g => !connection || g.instance_id === connection).forEach(g => el('queueGroup').add(new Option(`${g.meta.alias || g.name}`, `${g.instance_id}:${g.jid}`)));
  if (selected && !Array.from(el('queueGroup').options).some(o => o.value === selected) && existing) el('queueGroup').add(existing);
  el('queueGroup').value = selected;
  const checked = Array.from(el('queueProducts').querySelectorAll('input:checked')).map(i => i.value);
  el('queueProducts').innerHTML = state.messages.length ? state.messages.map(m => `<label class="checkbox"><input type="checkbox" value="${esc(m.id)}" ${checked.includes(m.id) ? 'checked' : ''}>${esc(m.title)}</label>`).join('') : '<p class="hint">Cadastre produtos na aba Mensagens.</p>';
  if (!el('queueId').value) el('queueTimezone').textContent = `Horários no fuso ${state.config?.timezone || 'America/Sao_Paulo'}.`;
  el('mediaUploadHint').textContent = `JPG, PNG, WebP, MP4 ou PDF. Limite atual do servidor: ${(state.uploadLimit / 1048576).toFixed(1)} MB.`;
  el('queuesList').innerHTML = state.queues.length ? state.queues.map(q => {
    const names = q.order.map(id => state.messages.find(m => m.id === id)?.title || 'Produto indisponível');
    return `<details class="queue-card"><summary>
      <h3>${esc(q.title)}</h3>
      <span class="badge ${q.in_flight ? 'failed' : q.enabled ? 'completed' : 'pending'}">${q.in_flight ? 'Revisão necessária' : q.enabled ? 'Ativa' : 'Pausada'}</span>
      <span>Ver detalhes</span></summary><p>${esc(q.group.name)}</p>
      ${q.schedule_mode === 'times' ? `<p>Horários: ${esc((q.send_times || []).join(', '))}</p>` : ''}
      <p class="hint">${esc(q.days.map(d => days[d]).join(', '))} · ${esc(q.start_time)}–${esc(q.end_time)} · a cada ${q.interval_minutes} min · ${esc(q.timezone)}</p>
      <p class="hint">Próximo horário: ${q.next_at ? esc(ctx.formatDate(q.next_at)) : '—'}</p>
      <p class="hint">Última chamada do cron: ${q.last_check_at ? esc(ctx.formatDate(q.last_check_at)) : 'Nenhuma recebida'}. ${esc(q.last_check_reason || '')}</p>
      <p class="hint">Último envio: ${q.last_sent_at ? esc(ctx.formatDate(q.last_sent_at)) : 'Nenhum'}. Job: ${esc(q.cron_job_id || 'Não registrado')}</p>
      <p class="hint">Ordem dos próximos produtos:</p><ol class="queue-order">${names.map(n => `<li>${esc(n)}</li>`).join('')}</ol>
      ${q.error ? `<p role="alert">${esc(q.error)}</p>` : ''}
      <div class="form-actions">
        <button type="button" class="btn btn-ghost" data-queue-edit="${esc(q.id)}">Editar</button>
        <button type="button" class="btn btn-ghost" data-queue-diagnose="${esc(q.id)}">Diagnosticar cron</button>
        <button type="button" class="btn btn-ghost" data-queue-repair="${esc(q.id)}">Reparar cron</button>
        ${q.in_flight ? `<button type="button" class="btn btn-primary" data-queue-review="${esc(q.id)}">Confirmar revisão</button>` : `<button type="button" class="btn btn-primary" data-queue-toggle="${esc(q.id)}">${q.enabled ? 'Pausar' : 'Iniciar'}</button>`}
        <button type="button" class="btn btn-danger" data-queue-delete="${esc(q.id)}">Excluir</button>
      </div></details>`;
  }).join('') : '<p class="empty">Nenhuma fila cadastrada.</p>';
}

function renderQueueTimes() {
  const input = el('queueTimes');
  const list = el('queueTimesList');
  if (!input || !list) return;
  const times = input.value.split(',').map(t => t.trim()).filter(Boolean).sort();
  input.value = [...new Set(times)].join(',');
  list.innerHTML = times.length
    ? times.map(time => `<span class="tag">${time}<button type="button" class="btn btn-ghost" data-remove-queue-time="${time}" aria-label="Remover horário ${time}">×</button></span>`).join('')
    : '<p class="hint">Nenhum horário adicionado.</p>';
}

export function initFeatures(context) {
  ctx = context;
  el('queueMode').onchange = () => {
    const exact = el('queueMode').value === 'times';
    el('queueTimesLabel').hidden = !exact;
    el('queueTimes').required = exact;
    ['queueStart','queueEnd','queueInterval'].forEach(id => { el(id).closest('label').hidden = exact; });
  };
  el('addQueueTime').onclick = () => {
    const picker = el('queueTimePicker');
    if (!picker.value) return;
    const values = el('queueTimes').value.split(',').map(item => item.trim()).filter(Boolean);
    if (!values.includes(picker.value)) values.push(picker.value);
    el('queueTimes').value = values.join(',');
    picker.value = '';
    renderQueueTimes();
  };
  el('queueTimesList').onclick = (event) => {
    const time = event.target.dataset.removeQueueTime;
    if (!time) return;
    el('queueTimes').value = el('queueTimes').value.split(',').filter(item => item !== time).join(',');
    renderQueueTimes();
  };
  el('generateCopy').onclick = async () => {
    const summary = el('aiSummary').value.trim();
    if (!summary) { el('aiCopyStatus').textContent = 'Escreva um resumo do produto ou oferta.'; el('aiSummary').focus(); return; }
    const revision = copyRevision;
    const button = el('generateCopy');
    button.disabled = true;
    button.textContent = 'Gerando copy…';
    el('aiCopyStatus').textContent = 'Preparando sua sugestão de texto…';
    el('aiCopyResult').hidden = true;
    try {
      const result = await ctx.api('generate-copy', {method: 'POST', body: {summary}});
      if (revision !== copyRevision) return;
      el('aiCopyText').value = result.copy;
      el('aiCopyResult').hidden = false;
      el('aiCopyStatus').textContent = 'Copy gerada. Revise e clique em Usar no texto / legenda.';
    } catch (error) {
      if (revision === copyRevision) el('aiCopyStatus').textContent = error.message;
    } finally {
      button.disabled = false;
      button.textContent = 'Gerar copy para WhatsApp';
    }
  };
  el('applyCopy').onclick = () => {
    const text = el('aiCopyText').value.trim();
    if (!text) return;
    el('messageContent').value = text;
    updateMessagePreview();
    el('aiCopyStatus').textContent = 'Texto aplicado à prévia. Salve a mensagem quando estiver pronta.';
    el('messageContent').focus();
  };
  ['messageContent', 'messageMediaUrl', 'messageMediaType', 'messageType', 'messageButtonEnabled', 'messageButtonType', 'messageButtonLabel', 'messageButtonUrl'].forEach(id => el(id).addEventListener('input', () => {
    if (id === 'messageMediaUrl' && el(id).value) resetMessageMedia(null);
    updateMessagePreview();
  }));
  el('messageMediaFile').addEventListener('change', () => {
    if (localPreview) URL.revokeObjectURL(localPreview);
    localPreview = '';
    const file = el('messageMediaFile').files[0];
    if (file) {
      if (file.size > ctx.state.uploadLimit) { el('messageMediaFile').value = ''; ctx.toast('Arquivo acima do limite do servidor.', 'error'); return; }
      savedMedia = null;
      el('messageMediaUrl').value = '';
      el('messageMediaType').value = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'document';
      localPreview = URL.createObjectURL(file);
    }
    updateMessagePreview();
  });
  el('removeMedia').onclick = () => resetMessageMedia(null);
  el('newQueue').onclick = () => editQueue(null);
  el('queueForm').onsubmit = async (event) => {
    event.preventDefault();
    const button = event.submitter;
    button.disabled = true;
    try {
      const key = el('queueGroup').value;
      const group = ctx.state.groups.find(g => `${g.instance_id}:${g.jid}` === key);
      const old = ctx.state.queues.find(q => q.id === el('queueId').value);
      const message_ids = Array.from(el('queueProducts').querySelectorAll('input:checked')).map(i => i.value);
      if (message_ids.length < 2) throw new Error('Selecione pelo menos dois produtos.');
      const result = await ctx.api('queues-save', {method: 'POST', body: {
        id: el('queueId').value || undefined, title: el('queueTitle').value,
        schedule_mode: el('queueMode').value, send_times: el('queueTimes').value.split(',').map(t => t.trim()).filter(Boolean),
        group: group ? {jid: group.jid, instance_id: group.instance_id, name: `${group.meta.alias || group.name} — ${group.instance_name}`} : old?.group,
        message_ids, start_time: el('queueStart').value, end_time: el('queueEnd').value,
        interval_minutes: Number(el('queueInterval').value), days: Array.from(el('queueDays').querySelectorAll('input:checked')).map(i => Number(i.value)),
      }});
      await ctx.loadAll();
      editQueue(result.queue);
      ctx.toast(result.queue.enabled ? 'Fila atualizada' : 'Fila salva. Clique em Iniciar para ativar.');
    } catch (error) { ctx.toast(error.message, 'error'); }
    finally { button.disabled = false; }
  };
  el('queuesList').onclick = async (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const id = button.dataset.queueEdit || button.dataset.queueToggle || button.dataset.queueDelete || button.dataset.queueReview || button.dataset.queueDiagnose || button.dataset.queueRepair;
    const queue = ctx.state.queues.find(q => q.id === id);
    if (!queue) return;
    if (button.dataset.queueEdit) { editQueue(queue); return; }
    button.disabled = true;
    try {
      let result;
      if (button.dataset.queueRepair) result = await ctx.api('queues-repair', {method:'POST', body:{id}});
      if (button.dataset.queueDiagnose) {
        result = await ctx.api('queues-diagnose', {method:'POST', body:{id}});
        const d = result.diagnostic;
        result.warning = `Cron ${d.enabled ? 'ativo' : 'desativado'}. Configuração ${d.configuration_matches ? 'correta' : 'divergente: use Reparar cron'}. Status remoto: ${d.lastStatus ?? 'desconhecido'}. Detalhes em Logs.`;
      }
      if (button.dataset.queueToggle) result = await ctx.api('queues-toggle', {method: 'POST', body: {id, enabled: !queue.enabled}});
      if (button.dataset.queueDelete) {
        if (!confirm('Excluir esta fila e seu agendamento remoto?')) return;
        result = await ctx.api('queues-delete', {method: 'POST', body: {id}});
        if (el('queueId').value === id) editQueue(null);
      }
      if (button.dataset.queueReview) {
        const answer = prompt('Confira no WhatsApp o produto que estava em envio. Digite ENVIADO se chegou ao grupo, ou NÃO ENVIADO se não chegou. Cancelar mantém a fila pausada.');
        if (answer === null) return;
        const normalized = answer.trim().toUpperCase();
        if (!['ENVIADO', 'NÃO ENVIADO', 'NAO ENVIADO'].includes(normalized)) throw new Error('Revisão não confirmada. Informe ENVIADO ou NÃO ENVIADO.');
        result = await ctx.api('queues-reviewed', {method: 'POST', body: {id, delivered: normalized === 'ENVIADO'}});
      }
      await ctx.loadAll();
      ctx.toast(result?.warning || 'Fila atualizada');
    } catch (error) { ctx.toast(error.message, 'error'); }
    finally { button.disabled = false; }
  };
  updateMessagePreview();
}
