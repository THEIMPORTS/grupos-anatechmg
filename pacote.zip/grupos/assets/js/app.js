import {initFeatures, refreshFeatures, resetMessageMedia, updateMessagePreview, messageMediaPayload, resetCopyEditor} from './features.js?v=1.3.11';
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[char])); }
const API_BASE = './api/index.php';
let csrfToken = '';

const state = {
  groups: [],
  messages: [],
  schedules: [],
  logs: [],
  config: null,
  selectedGroupJids: new Set(),
  instances: [],
  queues: [],
  uploadLimit: 2097152,
};

const titles = {
  dashboard: ['Painel', 'Visão geral das campanhas'],
  groups: ['Grupos', 'Sincronize e personalize seus grupos'],
  messages: ['Mensagens', 'Modelos salvos para divulgação'],
  schedules: ['Agendamentos', 'Envios programados para horário exato'],
  queues: ['Filas de produtos', 'Revezamento automático por grupo, dias e horário'],
  broadcast: ['Enviar agora', 'Disparo imediato em massa'],
  settings: ['Configurações', 'API Evogo e cron-job.org'],
  connections: ['Conexões', 'Cadastre e acompanhe suas instâncias Evolution GO'],
  updates: ['Atualização', 'Instale novas versões preservando seus dados'],
  logs: ['Logs e diagnóstico', 'Acompanhe envios, erros e chamadas do cron'],
};

async function api(action, options = {}) {
  const url = new URL(API_BASE, window.location.href);
  url.searchParams.set('action', action);

  if (options.query) {
    Object.entries(options.query).forEach(([key, value]) => {
      url.searchParams.set(key, value);
    });
  }

  const init = {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
  };

  if (options.body) {
    init.body = JSON.stringify(options.body);
  }
  if (options.formData) {
    delete init.headers['Content-Type'];
    init.body = options.formData;
  }

  const response = await fetch(url, init);
  let data;
  try { data = await response.json(); }
  catch { throw new Error('O servidor não retornou uma resposta válida. Verifique o limite do arquivo e a conexão.'); }
  if (data.install_required) { location.assign('./install.php'); throw new Error(data.error); }
  if (response.status === 401 && !['login', 'setup'].includes(action)) {
    document.getElementById('appShell').hidden = true;
    document.getElementById('loginScreen').hidden = false;
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.error || 'Erro na requisição');
  }

  return data;
}

function toast(message, type = 'success') {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.className = `toast show ${type}`;
  setTimeout(() => {
    el.className = 'toast';
  }, 3200);
}

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  return date.toLocaleString('pt-BR');
}

function statusBadge(status) {
  const label = {
    pending: 'Pendente',
    running: 'Enviando',
    completed: 'Concluído',
    failed: 'Falhou',
    partial: 'Parcial',
  }[status] || status;

  return `<span class="badge ${escapeHtml(status)}">${escapeHtml(label)}</span>`;
}

function groupKey(group) {
  return `${group.instance_id}:${group.jid}`;
}

function parseGroupKey(key) {
  const [instanceId, ...jidParts] = key.split(':');
  return { instanceId, jid: jidParts.join(':') };
}

function findGroupByKey(key) {
  return state.groups.find((g) => groupKey(g) === key);
}

function getSelectedGroups() {
  return state.groups.filter((g) => state.selectedGroupJids.has(groupKey(g)));
}

function getSelectedGroupItems() {
  return getSelectedGroups().map((g) => ({
    jid: g.jid,
    instance_id: g.instance_id,
  }));
}

function updateSelectedGroupsUI() {
  const selected = getSelectedGroups();
  const names = selected.map((g) => `${g.meta.alias || g.name} (${g.instance_name})`).join(', ') || 'Nenhum grupo selecionado. Marque na aba Grupos.';
  document.getElementById('scheduleSelectedGroups').textContent = names;
  document.getElementById('broadcastSelectedGroups').textContent = names;
  document.getElementById('broadcastCount').textContent = String(selected.length);
  renderBroadcastGroups();
}

function renderBroadcastGroups() {
  const query = document.getElementById('broadcastSearch').value.toLocaleLowerCase();
  const connection = document.getElementById('broadcastConnection')?.value || '';
  const groups = state.groups.filter(g => (!connection || g.instance_id === connection) && `${g.name} ${g.instance_name}`.toLocaleLowerCase().includes(query));
  document.getElementById('broadcastGroupChoices').innerHTML = groups.map(g => `<label class="checkbox"><input type="checkbox" data-broadcast-group="${escapeHtml(groupKey(g))}" ${state.selectedGroupJids.has(groupKey(g)) ? 'checked' : ''}>${escapeHtml(g.meta.alias || g.name)} — ${escapeHtml(g.instance_name)}</label>`).join('') || '<p class="hint">Nenhum grupo encontrado. Atualize os grupos e confira a conexão da instância.</p>';
}

function renderConnectionOptions() {
  const selects = ['scheduleConnection','queueConnection','broadcastConnection'].map(id => document.getElementById(id)).filter(Boolean);
  const html = '<option value="">Selecione a conexão</option>' + state.instances.map(i => `<option value="${escapeHtml(i.id)}">${escapeHtml(i.name)}${i.connected ? ' ✓' : ' ✗'}</option>`).join('');
  selects.forEach(s => { const current=s.value; s.innerHTML=html; if ([...s.options].some(o=>o.value===current)) s.value=current; });
  renderScopedGroups();
}

function renderScopedGroups() {
  const conn = document.getElementById('scheduleConnection')?.value || document.getElementById('broadcastConnection')?.value || '';
  const scheduleBox = document.getElementById('scheduleGroupChoices');
  if (scheduleBox) scheduleBox.innerHTML = state.groups.filter(g => !conn || g.instance_id === conn).map(g => `<label class="checkbox"><input type="checkbox" data-scoped-group="${escapeHtml(groupKey(g))}" ${state.selectedGroupJids.has(groupKey(g))?'checked':''}>${escapeHtml(g.meta.alias || g.name)}</label>`).join('') || '<p class="hint">Nenhum grupo para esta conexão.</p>';
  const q = document.getElementById('queueGroup'); const qc = document.getElementById('queueConnection')?.value || '';
  if (q) { const current=q.value; q.innerHTML='<option value="">Selecione um grupo</option>'+state.groups.filter(g=>!qc||g.instance_id===qc).map(g=>`<option value="${escapeHtml(g.instance_id+':'+g.jid)}">${escapeHtml(g.meta.alias||g.name)}</option>`).join(''); if ([...q.options].some(o=>o.value===current)) q.value=current; }
}

async function refreshLogs() {
  try {
    const data = await api('logs'); state.logs = data.logs || [];
    document.getElementById('cronHeartbeat').textContent = data.heartbeat ? `Última chamada autenticada do cron: ${formatDate(data.heartbeat.at)}. Servidor: ${formatDate(data.server_time)}.` : 'Nenhuma chamada autenticada do cron registrada. Confira a URL pública, o job no cron-job.org e use Diagnosticar cron na fila.';
    renderDetailedLogs();
  } catch (error) { toast(error.message, 'error'); }
}

function renderDetailedLogs() {
  const filter = document.getElementById('logsFilter').value;
  document.getElementById('logsDetailed').innerHTML = state.logs.filter(l => filter === 'all' || l.status === filter).map(l => `<article class="queue-card"><strong>${escapeHtml(l.title || l.type)}</strong> ${statusBadge(l.status)}<p class="hint">${escapeHtml(formatDate(l.created_at))} · ${escapeHtml(l.type || '')}</p><p>${escapeHtml(l.detail || '')}</p><small>${escapeHtml(l.group_jid || '')} ${escapeHtml(l.instance_id || '')}</small></article>`).join('') || '<p class="empty">Nenhum registro para este filtro.</p>';
}

function switchView(view) {
  if (view === 'logs') refreshLogs();
  if (view === 'updates') loadUpdates();
  if (view === 'connections') renderConnections();
  document.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });

  document.querySelectorAll('.view').forEach((section) => {
    section.classList.toggle('active', section.id === `view-${view}`);
  });

  const [title, subtitle] = titles[view] || ['Grupos Evogo', ''];
  document.getElementById('pageTitle').textContent = title;
  document.getElementById('pageSubtitle').textContent = subtitle;
}

function renderDashboard() {
  document.getElementById('statGroups').textContent = String(state.groups.length);
  document.getElementById('statMessages').textContent = String(state.messages.length);
  document.getElementById('statSchedules').textContent = String(state.schedules.length);
  document.getElementById('statPending').textContent = String(
    state.schedules.filter((s) => s.status === 'pending').length
  );

  const upcoming = [...state.schedules]
    .filter((s) => s.status === 'pending')
    .sort((a, b) => new Date(a.scheduled_at) - new Date(b.scheduled_at))
    .slice(0, 6);

  document.getElementById('upcomingList').innerHTML = upcoming.length
    ? upcoming.map((s) => `
      <div class="list-item">
        <div>
          <strong>${escapeHtml(s.title)}</strong>
          <small>${formatDate(s.scheduled_at)} · ${s.group_jids?.length || 0} grupos</small>
        </div>
        ${statusBadge(s.status)}
      </div>
    `).join('')
    : '<div class="empty">Nenhum agendamento pendente</div>';

  document.getElementById('logsList').innerHTML = state.logs.length
    ? state.logs.slice(0, 8).map((log) => `
      <div class="list-item">
        <div>
          <strong>${escapeHtml(log.title || log.type)}</strong>
          <small>${formatDate(log.created_at)} · ${log.groups || 0} grupos</small>
        </div>
        ${statusBadge(log.status)}
      </div>
    `).join('')
    : '<div class="empty">Sem logs ainda</div>';
}

function renderGroups() {
  const search = document.getElementById('groupSearch').value.trim().toLowerCase();
  const tagFilter = document.getElementById('groupTagFilter').value;
  const instanceFilter = document.getElementById('groupInstanceFilter').value;
  const enabledOnly = document.getElementById('groupEnabledOnly').checked;
  const adminOnly = document.getElementById('groupAdminOnly').checked;

  const filtered = state.groups.filter((group) => {
    const text = `${group.name} ${group.jid} ${group.instance_name} ${group.meta.alias} ${(group.meta.tags || []).join(' ')}`.toLowerCase();
    if (search && !text.includes(search)) return false;
    if (instanceFilter && group.instance_id !== instanceFilter) return false;
    if (enabledOnly && group.meta.enabled === false) return false;
    if (adminOnly && !group.is_admin) return false;
    if (tagFilter && !(group.meta.tags || []).includes(tagFilter)) return false;
    return true;
  });

  document.getElementById('groupsTable').innerHTML = filtered.map((group) => {
    const key = groupKey(group);
    return `
    <tr>
      <td><input type="checkbox" data-group-select="${escapeHtml(key)}" ${state.selectedGroupJids.has(key) ? 'checked' : ''}></td>
      <td>
        <strong>${escapeHtml(group.meta.alias || group.name)}</strong>
        <div class="hint">${escapeHtml(group.name)}</div>
        <div class="hint">${escapeHtml(group.jid)}</div>
        ${group.is_super_admin ? '<span class="badge super">Super admin</span>' : group.is_admin ? '<span class="badge admin">Admin</span>' : ''}
      </td>
      <td><span class="tag">${escapeHtml(group.instance_name || '-')}</span></td>
      <td>
        ${(group.meta.tags || []).map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}
      </td>
      <td>${group.meta.enabled === false ? '<span class="badge failed">Inativo</span>' : '<span class="badge completed">Ativo</span>'}</td>
      <td><button class="btn btn-ghost" data-edit-group="${escapeHtml(key)}">Personalizar</button></td>
    </tr>
  `;
  }).join('') || '<tr><td colspan="6" class="empty">Nenhum grupo encontrado</td></tr>';

  const tags = new Set();
  state.groups.forEach((g) => (g.meta.tags || []).forEach((t) => tags.add(t)));
  const tagSelect = document.getElementById('groupTagFilter');
  const currentTag = tagSelect.value;
  tagSelect.innerHTML = '<option value="">Todas as tags</option>' + [...tags].map((t) => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
  tagSelect.value = currentTag;

  const instanceSelect = document.getElementById('groupInstanceFilter');
  const currentInstance = instanceSelect.value;
  instanceSelect.innerHTML = '<option value="">Todas as instâncias</option>' + state.instances.map((i) =>
    `<option value="${escapeHtml(i.id)}">${escapeHtml(i.name)}${i.connected ? '' : ' (offline)'}</option>`
  ).join('');
  instanceSelect.value = currentInstance;

  const adminCount = filtered.filter((g) => g.is_admin).length;
  document.getElementById('groupsFilterSummary').textContent =
    `Exibindo ${filtered.length} de ${state.groups.length} grupos` +
    (adminOnly ? ` · ${adminCount} como admin` : '') +
    (instanceFilter ? ` · instância filtrada` : '');
}

function renderMessages() {
  document.getElementById('messagesList').innerHTML = state.messages.length
    ? state.messages.map((m) => `
      <div class="list-item" data-message-id="${escapeHtml(m.id)}">
        <div>
          <strong>${escapeHtml(m.title)}</strong>
          <small>${escapeHtml(m.type)} · ${formatDate(m.updated_at || m.created_at)}</small>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" data-message-edit="${escapeHtml(m.id)}" aria-label="Editar ${escapeHtml(m.title)}">Editar</button>
          <button type="button" class="btn btn-danger" data-message-delete="${escapeHtml(m.id)}" aria-label="Excluir ${escapeHtml(m.title)}">Excluir</button>
        </div>
      </div>
    `).join('')
    : '<div class="empty">Crie sua primeira mensagem</div>';

  const selects = [document.getElementById('scheduleMessage'), document.getElementById('broadcastMessage')];
  selects.forEach((select) => {
    select.innerHTML = state.messages.map((m) => `<option value="${escapeHtml(m.id)}">${escapeHtml(m.title)}</option>`).join('');
  });
}

function renderSchedules() {
  document.getElementById('schedulesList').innerHTML = state.schedules.length
    ? [...state.schedules]
      .sort((a, b) => new Date(b.scheduled_at) - new Date(a.scheduled_at))
      .map((s) => `
        <div class="list-item" data-schedule-id="${escapeHtml(s.id)}">
          <div>
            <strong>${escapeHtml(s.title)}</strong>
            <small>${formatDate(s.scheduled_at)} · ${s.group_jids?.length || 0} grupos</small>
          </div>
          ${statusBadge(s.status)}
        </div>
      `).join('')
    : '<div class="empty">Nenhum agendamento criado</div>';
}

function fillMessageForm(message) {
  resetCopyEditor();
  document.getElementById('messageId').value = message?.id || '';
  document.getElementById('messageTitle').value = message?.title || '';
  document.getElementById('messageType').value = message?.type || 'text';
  document.getElementById('messageContent').value = message?.content || '';
  document.getElementById('messageMediaUrl').value = message?.media_url || '';
  document.getElementById('messageMediaType').value = message?.media_type || 'image';
  document.getElementById('messageMentionAll').checked = !!message?.mention_all;
  document.getElementById('messageButtonEnabled').checked = !!message?.button_enabled;
  document.getElementById('messageButtonType').value = message?.button_type || 'reply';
  document.getElementById('messageButtonLabel').value = message?.button_label || '';
  document.getElementById('messageButtonUrl').value = message?.button_url || '';
  resetMessageMedia(message);
  toggleMediaFields();
}

function fillScheduleForm(schedule) {
  document.getElementById('scheduleId').value = schedule?.id || '';
  document.getElementById('scheduleTitle').value = schedule?.title || '';
  document.getElementById('scheduleMessage').value = schedule?.message_id || '';
  document.getElementById('scheduleMentionAll').checked = !!schedule?.mention_all;

  if (schedule?.scheduled_at) {
    const dt = new Date(schedule.scheduled_at);
    const local = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    document.getElementById('scheduleDateTime').value = local;
  } else {
    document.getElementById('scheduleDateTime').value = '';
  }

  if (schedule?.group_items?.length) {
    const firstConnection = schedule.group_items[0]?.instance_id || '';
    if (document.getElementById('scheduleConnection')) document.getElementById('scheduleConnection').value = firstConnection;
    state.selectedGroupJids = new Set(
      schedule.group_items.map((item) => `${item.instance_id}:${item.jid}`)
    );
  } else if (schedule?.group_jids) {
    state.selectedGroupJids = new Set(
      schedule.group_jids.map((jid) => {
        const match = state.groups.find((g) => g.jid === jid);
        return match ? groupKey(match) : jid;
      })
    );
  }

  renderGroups();
  renderScopedGroups();
  updateSelectedGroupsUI();
}

function toggleMediaFields() {
  const isMedia = document.getElementById('messageType').value === 'media';
  document.getElementById('mediaFields').classList.toggle('hidden', !isMedia);
  document.getElementById('messageContentLabel').firstChild.textContent = isMedia ? 'Legenda ' : 'Conteúdo ';
  updateMessagePreview();
}

function updateInstanceStatus(selected) {
  if (!document.getElementById('instanceStatus')) return;
  const pill = document.getElementById('instanceStatus');
  pill.classList.toggle('online', !!selected?.connected);
  pill.querySelector('span:last-child').textContent = selected
    ? `${selected.name} ${selected.connected ? '· online' : '· offline'}`
    : 'Sem instância';
}

async function loadAll() {
  const [configRes, messagesRes, schedulesRes, logsRes, queuesRes] = await Promise.all([
    api('config-get'),
    api('messages-list'),
    api('schedules-list'),
    api('logs'),
    api('queues-list'),
  ]);

  state.config = configRes.config;
  state.messages = messagesRes.messages || [];
  state.schedules = schedulesRes.schedules || [];
  state.logs = logsRes.logs || [];
  state.queues = queuesRes.queues || [];
  state.uploadLimit = messagesRes.upload_limit || 2097152;

  fillSettingsForm();
  renderMessages();
  renderSchedules();
  renderDashboard();
  updateSelectedGroupsUI();
  refreshFeatures();
}

async function syncInstances() {
  const data = await api('instances');
  state.instances = data.instances || [];
  updateInstanceStatus(data.selected);

  const select = document.getElementById('cfgInstance');
  if (!select) { renderConnections(); return; }
  select.innerHTML = state.instances.map((i) =>
    `<option value="${escapeHtml(i.id)}" ${i.id === data.selected?.id ? 'selected' : ''}>${escapeHtml(i.name)} ${i.connected ? '✓' : '✗'}</option>`
  ).join('');
  renderConnectionOptions();
  renderConnections();
}

function renderConnections() {
  const el = document.getElementById('connectionsList');
  if (!el) return;
  el.innerHTML = state.instances.map((i) => `<div class="list-item"><div><strong>${escapeHtml(i.name)}</strong><small>${escapeHtml(i.id)}</small></div>${i.connected ? '<span class="badge completed">Conectada</span>' : `<button type="button" class="btn btn-ghost" data-reconnect-instance="${escapeHtml(i.name)}">Reconectar</button>`}</div>`).join('') || '<p class="empty">Nenhuma conexão criada neste painel.</p>';
}

async function syncGroups() {
  document.getElementById('broadcastGroupStatus').textContent = 'Carregando grupos do Evolution GO…';
  try {
  const data = await api('groups', { query: { all: '1' } });
  state.groups = data.groups || [];
  if (data.instances?.length) {
    state.instances = data.instances;
  }
  renderConnectionOptions();
  renderGroups();
  renderDashboard();
  updateSelectedGroupsUI();
  refreshFeatures();
  document.getElementById('broadcastGroupStatus').textContent = `${state.groups.length} grupos carregados. ${(data.warnings || []).join(' ')}`;
  } catch (error) { document.getElementById('broadcastGroupStatus').textContent = error.message; throw error; }
}

function fillSettingsForm() {
  const cfg = state.config || {};
  const set = (id, prop, value) => { const el = document.getElementById(id); if (el) el[prop] = value; };
  set('cfgEvogoUrl', 'value', cfg.evogo_base_url || '');
  set('cfgGlobalKey', 'placeholder', cfg.global_api_key || 'API key global');
  set('cfgDelayMin', 'value', cfg.send_delay_min_seconds || cfg.send_delay_seconds || 4);
  set('cfgDelayMax', 'value', cfg.send_delay_max_seconds || cfg.send_delay_seconds || 4);
  set('cfgTimezone', 'value', cfg.timezone || 'America/Sao_Paulo');
  set('cfgPublicUrl', 'value', cfg.public_webhook_url || '');
  set('cfgWebhookSecret', 'value', cfg.webhook_secret || '');
  set('cfgCronKey', 'placeholder', cfg.cronjob_api_key || 'API key do cron-job.org');
  set('cfgOpenAIKey', 'placeholder', cfg.openai_api_key ? 'Chave salva — deixe vazio para manter' : 'Cole sua chave OpenAI');

  api('webhook-url').then((data) => {
    document.getElementById('webhookPreview').textContent = data.dispatch_example;
  }).catch(() => {});
}

async function openGroupModal(key) {
  const group = findGroupByKey(key);
  if (!group) return;

  document.getElementById('modalGroupJid').value = group.jid;
  document.getElementById('modalGroupInstance').value = group.instance_id || '';
  document.getElementById('groupModalTitle').textContent = group.meta.alias || group.name;
  document.getElementById('modalAlias').value = group.meta.alias || '';
  document.getElementById('modalTags').value = (group.meta.tags || []).join(', ');
  document.getElementById('modalColor').value = group.meta.color || '#22c55e';
  document.getElementById('modalNotes').value = group.meta.notes || '';
  document.getElementById('modalEnabled').checked = group.meta.enabled !== false;
  document.getElementById('modalWaName').value = group.name || '';
  document.getElementById('modalDescription').value = group.topic || '';
  document.getElementById('modalInviteResult').textContent = '';

  document.getElementById('groupModal').showModal();
}

function bindEvents() {
  document.getElementById('refreshLogs').onclick = refreshLogs;
  document.getElementById('logsFilter').onchange = renderDetailedLogs;
  document.getElementById('broadcastSearch').oninput = renderBroadcastGroups;
  document.getElementById('broadcastSyncGroups').onclick = async () => { try { await syncGroups(); } catch (error) { toast(error.message,'error'); } };
  document.getElementById('broadcastGroupChoices').onchange = (event) => {
    const key = event.target.dataset.broadcastGroup;
    if (!key) return;
    if (event.target.checked) state.selectedGroupJids.add(key); else state.selectedGroupJids.delete(key);
    updateSelectedGroupsUI(); renderGroups();
  };
  document.getElementById('reloadAfterUpdate').onclick = () => location.reload();
  document.getElementById('updateForm').onsubmit = async (event) => {
    event.preventDefault();
    const button = document.getElementById('installUpdate');
    const status = document.getElementById('updateStatus');
    const file = document.getElementById('updateFile').files[0];
    if (!file) return;
    button.disabled = true;
    status.textContent = 'Enviando e verificando o pacote. Aguarde a conclusão…';
    try {
      const data = new FormData(); data.append('file', file);
      const result = await api('updates-install', {method: 'POST', formData: data});
      status.textContent = `Atualização ${result.update.version} instalada. Seus dados foram preservados. Backup: ${result.update.backup}.`;
      document.getElementById('reloadAfterUpdate').hidden = false;
      document.getElementById('updateFile').value = '';
      await loadUpdates();
    } catch (error) { status.textContent = `${error.message} Se a conexão foi interrompida, confira a versão instalada antes de reenviar.`; }
    finally { button.disabled = false; }
  };
  initFeatures({api, state, escapeHtml, toast, formatDate, loadAll});
  document.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });
  document.getElementById('createInstance').addEventListener('click', async () => {
    const name = document.getElementById('newInstanceName').value.trim();
    if (!name) { toast('Informe o nome da instância', 'error'); return; }
    try {
      const created = await api('instance-create', {method:'POST', body:{name}});
      document.getElementById('newInstanceName').value = '';
      const qr = created.instance?.qrcode || created.instance?.qrCode || created.instance?.qr || created.instance?.base64;
      const qrBox = document.getElementById('connectionQr');
      if (qrBox && qr) { const src = String(qr).startsWith('data:') ? qr : `data:image/png;base64,${qr.replace(/^data:image\/\w+;base64,/, '')}`; qrBox.hidden = false; qrBox.innerHTML = `<h3>Escaneie este QR Code no WhatsApp</h3><img alt="QR Code da conexão" style="max-width:320px;background:#fff;padding:12px;border-radius:12px" src="${escapeHtml(src)}"><p class="hint">O QR Code fica nesta tela; não é necessário abrir o Evolution GO Manager.</p>`; }
      await syncInstances();
      toast('Instância criada. Clique em Reconectar para obter o QR Code nesta tela.');
    } catch (error) { toast(error.message, 'error'); }
  });
  document.getElementById('connectionsList').addEventListener('click', async (event) => {
    const name = event.target.dataset.reconnectInstance; if (!name) return;
    event.target.disabled = true;
    try {
      const box = document.getElementById('connectionQr');
      box.hidden = false;
      box.textContent = 'Aguardando geração do QR Code…';
      box.scrollIntoView({behavior:'smooth', block:'center'});
      let result = await api('instance-reconnect', {method:'POST', body:{name}});
      const extractQr = data => {
        if (!data || typeof data !== 'object') return '';
        for (const key of ['qrcode','qrCode','base64','qr']) {
          const value = data[key];
          if (typeof value === 'string' && value) return value;
          if (value && typeof value === 'object') { const nested = extractQr(value); if (nested) return nested; }
        }
        return data.data ? extractQr(data.data) : '';
      };
      let qr = extractQr(result.connection);
      for (let attempt = 0; !qr && attempt < 10; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        result = await api('instance-qr', {method:'POST', body:{name}});
        qr = extractQr(result.connection);
      }
      if (typeof qr === 'string' && qr) {
        const src = qr.startsWith('data:image/') ? qr : `data:image/png;base64,${qr}`;
        box.innerHTML = `<h3>Escaneie no WhatsApp — ${escapeHtml(name)}</h3><img alt="QR Code da conexão" style="max-width:320px;background:white;padding:12px" src="${escapeHtml(src)}">`;
        toast('QR Code disponível nesta tela.');
      } else {
        box.textContent = 'Conexão iniciada. Se ainda não estiver conectada, clique em Reconectar novamente para consultar o QR Code.';
      }
      await syncInstances();
    }
    catch (error) { document.getElementById('connectionQr').textContent = error.message; toast(error.message, 'error'); } finally { event.target.disabled = false; }
  });

  document.getElementById('groupSearch').addEventListener('input', renderGroups);
  document.getElementById('groupTagFilter').addEventListener('change', renderGroups);
  document.getElementById('groupInstanceFilter').addEventListener('change', renderGroups);
  document.getElementById('groupAdminOnly').addEventListener('change', renderGroups);
  document.getElementById('groupEnabledOnly').addEventListener('change', renderGroups);
  ['scheduleConnection','queueConnection','broadcastConnection'].forEach(id => document.getElementById(id)?.addEventListener('change', () => { state.selectedGroupJids = new Set(); renderScopedGroups(); renderBroadcastGroups(); updateSelectedGroupsUI(); }));
  document.getElementById('scheduleGroupChoices')?.addEventListener('change', (event) => {
    const key = event.target.dataset.scopedGroup; if (!key) return;
    event.target.checked ? state.selectedGroupJids.add(key) : state.selectedGroupJids.delete(key);
    updateSelectedGroupsUI();
  });

  document.getElementById('selectAllGroups').addEventListener('change', (event) => {
    const checked = event.target.checked;
    const search = document.getElementById('groupSearch').value.trim().toLowerCase();
    const tagFilter = document.getElementById('groupTagFilter').value;
    const instanceFilter = document.getElementById('groupInstanceFilter').value;
    const enabledOnly = document.getElementById('groupEnabledOnly').checked;
    const adminOnly = document.getElementById('groupAdminOnly').checked;

    state.groups.forEach((g) => {
      const text = `${g.name} ${g.jid} ${g.instance_name} ${g.meta.alias} ${(g.meta.tags || []).join(' ')}`.toLowerCase();
      const visible = (!search || text.includes(search))
        && (!instanceFilter || g.instance_id === instanceFilter)
        && (!enabledOnly || g.meta.enabled !== false)
        && (!adminOnly || g.is_admin)
        && (!tagFilter || (g.meta.tags || []).includes(tagFilter));

      if (!visible || g.meta.enabled === false) return;

      const key = groupKey(g);
      if (checked) state.selectedGroupJids.add(key);
      else state.selectedGroupJids.delete(key);
    });
    renderGroups();
    updateSelectedGroupsUI();
  });

  document.getElementById('groupsTable').addEventListener('change', (event) => {
    const key = event.target.dataset.groupSelect;
    if (!key) return;
    if (event.target.checked) state.selectedGroupJids.add(key);
    else state.selectedGroupJids.delete(key);
    updateSelectedGroupsUI();
  });

  document.getElementById('groupsTable').addEventListener('click', (event) => {
    const key = event.target.dataset.editGroup;
    if (key) openGroupModal(key);
  });

  document.getElementById('messageType').addEventListener('change', toggleMediaFields);

  document.getElementById('btnNewMessage').addEventListener('click', () => fillMessageForm(null));

  document.getElementById('messagesList').addEventListener('click', async (event) => {
    const item = event.target.closest('[data-message-id]');
    if (!item) return;
    const message = state.messages.find((m) => m.id === item.dataset.messageId);
    if (event.target.closest('[data-message-delete]')) {
      if (!confirm(`Excluir a mensagem "${message.title}"?`)) return;
      const button = event.target.closest('button');
      button.disabled = true;
      try {
        await api('messages-delete', {method: 'POST', body: {id: message.id}});
        if (document.getElementById('messageId').value === message.id) fillMessageForm(null);
        await loadAll();
        toast('Mensagem excluída');
      } catch (error) { toast(error.message, 'error'); }
      finally { button.disabled = false; }
      return;
    }
    fillMessageForm(message);
    document.getElementById('messageTitle').focus();
  });

  document.getElementById('messageForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = event.submitter;
    button.disabled = true;
    try {
      const media = await messageMediaPayload();
      const saved = await api('messages-save', {
        method: 'POST',
        body: {
          id: document.getElementById('messageId').value || undefined,
          title: document.getElementById('messageTitle').value,
          type: document.getElementById('messageType').value,
          content: document.getElementById('messageContent').value,
          media_url: document.getElementById('messageMediaUrl').value,
          media_type: document.getElementById('messageMediaType').value,
          mention_all: document.getElementById('messageMentionAll').checked,
          button_enabled: document.getElementById('messageButtonEnabled').checked,
          button_type: document.getElementById('messageButtonType').value,
          button_label: document.getElementById('messageButtonLabel').value,
          button_url: document.getElementById('messageButtonUrl').value,
          ...media,
        },
      });
      await loadAll();
      fillMessageForm(saved.message);
      toast('Mensagem salva');
    } catch (error) {
      toast(error.message, 'error');
    } finally { button.disabled = false; }
  });

  document.getElementById('btnDeleteMessage').addEventListener('click', async () => {
    const id = document.getElementById('messageId').value;
    if (!id || !confirm('Excluir esta mensagem?')) return;
    try {
      await api('messages-delete', { method: 'POST', body: { id } });
      fillMessageForm(null);
      await loadAll();
      toast('Mensagem excluída');
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.getElementById('btnNewSchedule').addEventListener('click', () => fillScheduleForm(null));

  document.getElementById('schedulesList').addEventListener('click', (event) => {
    const item = event.target.closest('[data-schedule-id]');
    if (!item) return;
    const schedule = state.schedules.find((s) => s.id === item.dataset.scheduleId);
    fillScheduleForm(schedule);
  });

  document.getElementById('scheduleForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const groupItems = getSelectedGroupItems();
    if (!groupItems.length) {
      toast('Selecione ao menos um grupo', 'error');
      return;
    }

    const localDate = document.getElementById('scheduleDateTime').value;
    const scheduledAt = new Date(localDate).toISOString();

    try {
      await api('schedules-save', {
        method: 'POST',
        body: {
          id: document.getElementById('scheduleId').value || undefined,
          title: document.getElementById('scheduleTitle').value,
          message_id: document.getElementById('scheduleMessage').value,
          scheduled_at: scheduledAt,
          mention_all: document.getElementById('scheduleMentionAll').checked,
          group_items: groupItems,
        },
      });
      await loadAll();
      toast('Agendamento salvo');
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.getElementById('btnDeleteSchedule').addEventListener('click', async () => {
    const id = document.getElementById('scheduleId').value;
    if (!id || !confirm('Excluir este agendamento?')) return;
    try {
      await api('schedules-delete', { method: 'POST', body: { id } });
      fillScheduleForm(null);
      await loadAll();
      toast('Agendamento excluído');
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.getElementById('broadcastForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const groupItems = getSelectedGroupItems();
    if (!groupItems.length) {
      toast('Selecione pelo menos um grupo nesta tela.', 'error');
      return;
    }

    if (!confirm(`Enviar agora para ${groupItems.length} grupo(s)?`)) return;
    const button = event.submitter;
    button.disabled = true; button.textContent = 'Enviando…';
    try {
      const data = await api('send-now', {
        method: 'POST',
        body: {
          message_id: document.getElementById('broadcastMessage').value,
          group_items: groupItems,
          mention_all: document.getElementById('broadcastMentionAll').checked,
        },
      });
      await loadAll();
      toast(`Envio finalizado: ${data.status}. Consulte Logs para ver os resultados.`);
    } catch (error) {
      toast(error.message, 'error');
    } finally { button.disabled = false; button.textContent = 'Enviar agora para os grupos'; }
  });

  document.getElementById('settingsForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const body = {
      evogo_base_url: document.getElementById('cfgEvogoUrl').value,
      send_delay_min_seconds: Number(document.getElementById('cfgDelayMin').value),
      send_delay_max_seconds: Number(document.getElementById('cfgDelayMax').value),
      timezone: document.getElementById('cfgTimezone').value,
      public_webhook_url: document.getElementById('cfgPublicUrl').value,
    };

    const globalKey = document.getElementById('cfgGlobalKey').value;
    const cronKey = document.getElementById('cfgCronKey').value;
    if (globalKey) body.global_api_key = globalKey;
    if (cronKey) body.cronjob_api_key = cronKey;
    const openAIKey = document.getElementById('cfgOpenAIKey').value.trim();
    if (openAIKey) body.openai_api_key = openAIKey;
    body.remove_openai_key = document.getElementById('cfgRemoveOpenAIKey').checked;

    try {
      await api('config-save', { method: 'POST', body });
      document.getElementById('cfgOpenAIKey').value = '';
      document.getElementById('cfgRemoveOpenAIKey').checked = false;
      await loadAll();
      toast('Configurações salvas');
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.getElementById('groupModalForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const jid = document.getElementById('modalGroupJid').value;
    const instanceId = document.getElementById('modalGroupInstance').value;

    try {
      await api('group-meta', {
        method: 'POST',
        body: {
          jid,
          alias: document.getElementById('modalAlias').value,
          tags: document.getElementById('modalTags').value.split(',').map((t) => t.trim()).filter(Boolean),
          color: document.getElementById('modalColor').value,
          notes: document.getElementById('modalNotes').value,
          enabled: document.getElementById('modalEnabled').checked,
        },
      });

      const waName = document.getElementById('modalWaName').value;
      const description = document.getElementById('modalDescription').value;

      if (waName) {
        await api('group-action', { method: 'POST', body: { action: 'name', group_jid: jid, instance_id: instanceId, name: waName } });
      }
      if (description) {
        await api('group-action', { method: 'POST', body: { action: 'description', group_jid: jid, instance_id: instanceId, description } });
      }

      await syncGroups();
      document.getElementById('groupModal').close();
      toast('Grupo atualizado');
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.getElementById('modalInviteLink').addEventListener('click', async () => {
    const jid = document.getElementById('modalGroupJid').value;
    const instanceId = document.getElementById('modalGroupInstance').value;
    try {
      const data = await api('group-action', { method: 'POST', body: { action: 'invitelink', group_jid: jid, instance_id: instanceId } });
      const link = data.data?.data?.inviteLink || data.data?.inviteLink || JSON.stringify(data.data);
      document.getElementById('modalInviteResult').textContent = `Link: ${link}`;
    } catch (error) {
      toast(error.message, 'error');
    }
  });

  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => document.getElementById('groupModal').close());
  });
}

async function loadUpdates() {
  try {
    const info = await api('updates-info');
    document.getElementById('installedVersion').textContent = `Versão ${info.version}`;
    document.getElementById('updateLimit').textContent = `Limite do pacote: ${(info.limit / 1048576).toFixed(1)} MB.`;
    document.getElementById('installUpdate').disabled = !info.zip_available;
    if (!info.zip_available) document.getElementById('updateStatus').textContent = 'Ative a extensão ZIP do PHP no servidor.';
    document.getElementById('updatesHistory').innerHTML = info.history.length ? info.history.map(item => `<div class="list-item"><div><strong>${escapeHtml(item.from)} → ${escapeHtml(item.version)}</strong><small>${escapeHtml(formatDate(item.at))} · ${Number(item.files)} arquivos</small></div></div>`).join('') : '<p class="empty">Nenhuma atualização instalada por este menu.</p>';
  } catch (error) { document.getElementById('updateStatus').textContent = error.message; }
}

async function init() {
  bindEvents();
  try {
    await loadAll();
    await syncInstances();
    await syncGroups();
  } catch (error) {
    toast(`Falha ao iniciar: ${error.message}. Use http://localhost/grupos/ com Laragon.`, 'error');
  }
}

async function startSession() {
  try {
    const session = await api('auth-status');
    csrfToken = session.csrf;
    if (session.authenticated) {
      document.getElementById('loginScreen').hidden = true;
      document.getElementById('appShell').hidden = false;
      await init();
      return;
    }
    if (session.setup) {
      document.getElementById('loginTitle').textContent = 'Crie seu acesso';
      document.getElementById('loginHint').textContent = 'Cadastre o administrador pelo acesso local. Use uma senha com pelo menos 12 caracteres.';
      document.getElementById('loginPassword').minLength = 12;
      document.getElementById('loginPassword').autocomplete = 'new-password';
      document.getElementById('loginSubmit').textContent = 'Criar acesso';
    }
    document.getElementById('loginForm').onsubmit = async (event) => {
      event.preventDefault();
      const button = document.getElementById('loginSubmit');
      button.disabled = true;
      try {
        await api(session.setup ? 'setup' : 'login', { method: 'POST', body: {
          email: document.getElementById('loginEmail').value,
          password: document.getElementById('loginPassword').value,
        }});
        location.reload();
      } catch (error) {
        document.getElementById('loginError').textContent = error.message;
      } finally { button.disabled = false; }
    };
  } catch (error) { document.getElementById('loginError').textContent = error.message; }
}
document.getElementById('btnLogout').onclick = async () => {
  try { await api('logout', {method: 'POST'}); location.reload(); }
  catch (error) { toast(error.message, 'error'); }
};
startSession();
