#!/usr/bin/env bash
# Define um novo codigo de instalacao quando o original nao esta em maos.
set -euo pipefail
cd "$(dirname "$0")/.."
CODIGO="${1:-}"
if [ -z "$CODIGO" ]; then echo "Uso: ./deploy/definir-codigo.sh SEU-CODIGO-FORTE"; exit 1; fi
docker compose -f deploy/docker-compose.yml exec -T app php -r \
  'file_put_contents("/var/www/html/data/install-token.php", "<?php return ".var_export(password_hash($argv[1], PASSWORD_DEFAULT), true).";");' -- "$CODIGO"
echo "Codigo de instalacao atualizado. Use exatamente: $CODIGO"
