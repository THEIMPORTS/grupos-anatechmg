# Grupos ANATECH MG — instalação na VPS da Oracle Cloud

Aplicação: Grupos ANATECH MG (base Grupos Evogo 1.3.13), painel web em PHP 8.2 + MySQL/MariaDB,
que agenda e dispara divulgação nos grupos de WhatsApp usando a Evolution API.

Este guia assume Ubuntu 22.04 na Oracle Cloud (Ampere A1, arquitetura ARM). O pacote já vem
com Docker, Caddy (HTTPS automático) e backup configurados.

---

## 1. Criar a máquina na Oracle Cloud

1. Entre em https://cloud.oracle.com e faça login.
2. Menu → Compute → Instances → Create instance.
3. Name: `anatech-grupos`
4. Image: Canonical Ubuntu 22.04 (aarch64).
5. Shape: Ampere → VM.Standard.A1.Flex → 2 OCPU e 12 GB (dentro do sempre gratuito).
6. Em Networking, marque "Assign a public IPv4 address".
7. Em SSH keys, baixe a chave privada (guarde o arquivo .key).
8. Create. Anote o *Public IP address* da máquina.

## 2. Abrir as portas 80 e 443

Na Oracle, o firewall é duplo. Precisa liberar nos dois.

1. Compute → Instances → sua instância → clique na subnet → Security Lists → Default Security List.
2. Add Ingress Rules, duas vezes:
   - Source CIDR: `0.0.0.0/0`, IP Protocol: TCP, Destination Port Range: `80`
   - Source CIDR: `0.0.0.0/0`, IP Protocol: TCP, Destination Port Range: `443`

Dentro do servidor (passo 4) liberamos o firewall interno.

## 3. Apontar o domínio no Registro.br

1. Entre em https://registro.br → seu domínio `anatechmg.com.br` → DNS.
2. Crie um registro tipo **A**:
   - Nome: `grupos`
   - Valor: IP público da VM da Oracle
3. Salve. A propagação leva de minutos até algumas horas.

## 4. Conectar no servidor e preparar

```bash
ssh -i sua-chave.key ubuntu@IP_DA_VM
sudo apt update && sudo apt upgrade -y
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 443 -j ACCEPT
sudo netfilter-persistent save
sudo apt install -y docker.io docker-compose-plugin unzip
sudo usermod -aG docker ubuntu
newgrp docker
```

## 5. Enviar o pacote e subir

No seu computador:

```bash
scp -i sua-chave.key grupos-anatechmg-1.3.13.zip ubuntu@IP_DA_VM:/home/ubuntu/
```

No servidor:

```bash
cd /home/ubuntu
unzip grupos-anatechmg-1.3.13.zip -d grupos
cd grupos
cp deploy/.env.example deploy/.env
nano deploy/.env
```

Preencha no `.env`:

```
DOMAIN=grupos.anatechmg.com.br
DB_NAME=grupos
DB_USER=grupos
DB_PASSWORD=uma-senha-forte-aqui
DB_ROOT_PASSWORD=outra-senha-forte-aqui
```

Suba tudo:

```bash
chmod +x deploy/deploy.sh deploy/backup.sh
./deploy/deploy.sh
```

O Caddy emite o certificado HTTPS sozinho, desde que o DNS do passo 3 já aponte para o IP.

## 6. Concluir a instalação pelo navegador

1. Abra `https://grupos.anatechmg.com.br/install.php`
2. Confira os requisitos (todos com visto verde).
3. Código de instalação: é o código que veio no pacote original (arquivo `data/install-token.php`).
   Se você não recebeu o código em texto, gere um novo no servidor:

```bash
cd /home/ubuntu/grupos
docker compose -f deploy/docker-compose.yml exec -T app \
  php -r 'file_put_contents("/var/www/html/data/install-token.php", "<?php return ".var_export(password_hash("SEU-CODIGO-AQUI", PASSWORD_DEFAULT), true).";");'
```

4. Banco de dados:
   - Host: `db`
   - Porta: `3306`
   - Nome, usuário e senha: os mesmos do `deploy/.env`
5. URL pública: `https://grupos.anatechmg.com.br`
6. Administrador: seu e-mail e uma senha com no mínimo 12 caracteres.
7. Instalar sistema.

## 7. Configurar dentro do painel

1. **Conexões**: URL da Evolution API, nome da instância e a chave de API (apikey) do seu servidor Evolution.
2. **Configurações**: chave da OpenAI (se for usar geração de texto), fuso horário e limites de envio.
3. **Grupos**: sincronizar os grupos da instância conectada.
4. **Agendamentos**: criar o primeiro disparo de teste para um grupo só, com intervalo alto entre mensagens.

## 8. Disparo automático (cron)

O app foi feito para usar o cron-job.org, e o cadastro é feito pelo próprio painel na tela de Agendamentos.
Se preferir usar o cron do servidor, adicione:

```bash
crontab -e
```

```cron
*/5 * * * * curl -s -X POST -H "X-Webhook-Secret: SEU_SEGREDO" "https://grupos.anatechmg.com.br/api/dispatch.php?id=ID_DO_AGENDAMENTO" > /dev/null
```

O segredo está em Configurações do painel (webhook_secret).

## 9. Backup diário

```bash
crontab -e
```

```cron
0 3 * * * /home/ubuntu/grupos/deploy/backup.sh >> /home/ubuntu/grupos/backups/backup.log 2>&1
```

Guarda 14 dias de banco e de arquivos em `backups/`.

## 10. Atualizar versão depois

```bash
cd /home/ubuntu/grupos
./deploy/backup.sh
unzip -o nova-versao.zip -d .
./deploy/deploy.sh
```

## 11. Checklist de segurança

1. Senha do painel com 12 caracteres ou mais, diferente de qualquer outra sua.
2. Ativar autenticação em dois fatores na conta Oracle.
3. Nunca expor a porta 3306 do banco para a internet (no compose ela fica só na rede interna).
4. Manter o backup rodando e testar a restauração uma vez.
5. Atualizar o servidor uma vez por mês: `sudo apt update && sudo apt upgrade -y`.

## 12. Se algo der errado

1. `docker compose -f deploy/docker-compose.yml ps` mostra se os três containers estão de pé.
2. `docker compose -f deploy/docker-compose.yml logs -f app` mostra o erro do PHP.
3. Certificado não sai: confira se o DNS já aponta para o IP (`dig grupos.anatechmg.com.br`).
4. Página em branco: `docker compose -f deploy/docker-compose.yml exec app php -v` e confira as extensões.
5. Erro de conexão com o banco: host tem que ser `db`, nunca `localhost`.
