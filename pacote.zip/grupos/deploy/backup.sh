#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

set -a
source deploy/.env
set +a

mkdir -p backups
STAMP=$(date +%Y%m%d-%H%M)

docker compose -f deploy/docker-compose.yml exec -T db \
  mariadb-dump -u"$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" | gzip > "backups/banco-$STAMP.sql.gz"

tar czf "backups/dados-$STAMP.tar.gz" data

find backups -type f -mtime +14 -delete

echo "Backup gerado: banco-$STAMP.sql.gz e dados-$STAMP.tar.gz"
