#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -f deploy/.env ]; then
  echo "ERRO: crie o arquivo deploy/.env copiando deploy/.env.example"
  exit 1
fi

mkdir -p data backups
chown -R 33:33 data 2>/dev/null || true

echo "Subindo containers..."
docker compose -f deploy/docker-compose.yml --env-file deploy/.env up -d --build

sleep 8
docker compose -f deploy/docker-compose.yml ps

DOMINIO=$(grep '^DOMAIN=' deploy/.env | cut -d= -f2)
echo
echo "Pronto. Abra: https://$DOMINIO/install.php"
echo "Logs: docker compose -f deploy/docker-compose.yml logs -f app"
